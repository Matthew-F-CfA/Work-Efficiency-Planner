Description:
This work efficiency planner is designed to help an employer estimate the time and cost it will take
for a set of workers to complete a a set of jobs. It is not guaranteed to find the best time or cost
for completing a project.

Execute Selector.jar to open a dialog box for choosing the individual Creator frames.

How to Use:
Create Jobs using JobCreator.jar
Create Workers using WorkerCreator.jar
Optional: Create WorkerBatches using WorkerBatchCreator.jar
Create JobCollections using JobCollectionCreator.jar
Create a work plan using PlannerCreator.jar

For WorkerCreator entering a value of 1.0 for Work Rate means the worker works at an average workers pace.
Entering 0.5 for Work Rate means the worker works at a pace half as fast as the average worker.
Entering 2.0 for Work Rate means the worker works at a pace twice as fast as the average worker.

For WorkerCreator entering a value of 10.0 for Pay Rate means the worker should be paid $10 per half hour
which is the same as $20 per hour.

For JobCreator and JobCollectionCreator the Pay Rate works the same as for WorkerCreator.

For JobCollectionCreator the Half Hours to Complete Job means that if you enter 4 then the job is
estimated to take 2 hours. Or, if you entered 5 then 2.5 hours.

Maximum time limit for PlannerCreator is measured in half hours, so entering a value of 100 means 50 hours.

All work plan output is displayed as hours not half hours.

When using WorkerCreator you must click the "Add Worker / Set Description, Proficiencies" after entering
the worker's name(but before adding proficiencies and restrictions) then click it again after setting the
description or adding/removing proficiencies. If you don't then changes won't be saved.