package bim.workEfficiencyPlanner;

import java.util.Vector;

class WorkerPool
implements Cloneable {
  volatile Vector vecAvailableWorkers=new Vector();
  volatile Vector vecBusyWorkers=new Vector();

  volatile Vector vecAvailableWorkersCopy=new Vector();
  volatile Vector vecBusyWorkersCopy=new Vector();

  volatile Boolean blnProcessPriority=new Boolean(true);
  volatile Double dblProcessPriorityLimiter=new Double(0.0d);

  volatile Vector vecArrangement=new Vector();  //Vector of Vectors with elements of SpecificJobArrangement
  volatile Integer intAvailableIndex=new Integer(0);

  volatile SpecificJobCollection collection=null;
  volatile SpecificJobCollection collectionIncrementCopy=null;

  volatile Boolean blnCompleted=new Boolean(false);

  volatile Integer intTotalElapsedHalfHours=new Integer(0);
  volatile Integer intTotalElapsedHalfHoursCopy=new Integer(0);

  volatile Double dblTotalCost=new Double(0.0d);
  volatile Double dblTotalCostCopy=new Double(0.0d);

//  Boolean blnLimited=new Boolean(false);

  volatile Vector vecAvailableWorkersJobsCopyJobs=new Vector();
  volatile Vector vecAvailableWorkersJobsCopyJobs2=new Vector();
//  Vector vecAvailableWorkersJobsCopy=new Vector();

  volatile boolean blnUseCriteria[]=new boolean[0];

  volatile double dblWorkRates[]=new double[0];

  volatile double dblPayRates[]=new double[0];

  volatile boolean blnUseWorkRates[]=new boolean[0];

  volatile boolean blnUsePayRates[]=new boolean[0];


  WorkerPool() {
  }

  WorkerPool(SpecificJobCollection collection, boolean blnUseCriteria[], double dblWorkRates[], double dblPayRates[], boolean blnUseWorkRates[], boolean blnUsePayRates[]) {
    this.collection=collection;
    this.blnUseCriteria=blnUseCriteria;
    this.dblWorkRates=dblWorkRates;
    this.dblPayRates=dblPayRates;
    this.blnUseWorkRates=blnUseWorkRates;
    this.blnUsePayRates=blnUsePayRates;
  }

  public Vector getAvailableWorkers() {
    return vecAvailableWorkers;
  }

  public void setAvailableWorkers(Vector vecAvailableWorkers) {
    this.vecAvailableWorkers=vecAvailableWorkers;
  }

  public Vector getBusyWorkers() {
    return vecBusyWorkers;
  }

  public void setBusyWorkers(Vector vecBusyWorkers) {
    this.vecBusyWorkers=vecBusyWorkers;
  }

  public boolean getProcessPriority() {
    return blnProcessPriority.booleanValue();
  }

  public void setProcessPriority(boolean blnProcessPriority0) {
    this.blnProcessPriority=new Boolean(blnProcessPriority0);
  }

  public double getProcessPriorityLimiter() {
    return dblProcessPriorityLimiter.doubleValue();
  }

  public void setProcessPriorityLimiter(double dblProcessPriorityLimiter0) {
    this.dblProcessPriorityLimiter=new Double(dblProcessPriorityLimiter0);
  }

  public Vector getArrangement() {
    return vecArrangement;
  }

  public void setArrangement(Vector vecArrangement) {
    this.vecArrangement=vecArrangement;
  }

  public int getAvailableIndex() {
    return intAvailableIndex.intValue();
  }

  public void setAvailableIndex(int intAvailableIndex0) {
    this.intAvailableIndex=new Integer(intAvailableIndex0);
  }

  public SpecificJobCollection getJobCollection() {
    return collection;
  }

  public void setJobCollection(SpecificJobCollection collection) {
    this.collection=collection;
  }

  public boolean isCompleted() {
    return blnCompleted.booleanValue();
  }

  public void setIsCompleted(boolean blnCompleted0) {
    this.blnCompleted=new Boolean(blnCompleted0);
  }

  public int getTotalElapsedHalfHours() {
    return intTotalElapsedHalfHours.intValue();
  }

  public void setTotalElapsedHalfHours(int intTotalElapsedHalfHours0) {
    this.intTotalElapsedHalfHours=new Integer(intTotalElapsedHalfHours0);
  }

  public double getTotalCost() {
    return dblTotalCost.doubleValue();
  }

  public void setTotalCost(double dblTotalCost0) {
    this.dblTotalCost=new Double(dblTotalCost0);
  }

/*
  public boolean didLimited() {
    return blnLimited.booleanValue();
  }

  public void setDidLimited(boolean blnLimited0) {
    this.blnLimited=new Boolean(blnLimited0);
  }
*/

  public void setIncrement() {
    intAvailableIndex=new Integer(0);
//    vecArrangement.removeAllElements();

    setIsCompleted(false);

    vecArrangement=createArrangements();

/*
for(int i=0;i<vecArrangement.size();i++) {
Vector vecElement=(Vector)vecArrangement.elementAt(i);
if(vecElement.size()>1)
System.out.println("greater than 1:"+vecElement.size());
}
*/
  }

  public String[] verifyJobCollectionCompletable() {
    Vector vecJobCollection=collection.getJobCollection();

    Vector vecCompletable=new Vector();
    for(int i=0;i<vecJobCollection.size();i++) {
      if(blnUseCriteria[i])
        vecCompletable.addElement(new Boolean(false));
      else
        vecCompletable.addElement(new Boolean(true));
    }

    Vector vecAvailableWorkersJobs=getAvailableWorkersJobs();

    for(int i=0;i<vecAvailableWorkersJobs.size();i++) {
      Vector vecSpecificJobIndexes=(Vector)vecAvailableWorkersJobs.elementAt(i);

      for(int ia=0;ia<vecSpecificJobIndexes.size();ia++) {
        int intNextIndex=((Integer)vecSpecificJobIndexes.elementAt(ia)).intValue();

        vecCompletable.setElementAt(new Boolean(true), intNextIndex);
      }
    }

    Vector vecMessages=new Vector();

    for(int i=0;i<vecCompletable.size();i++) {
      boolean blnNext=((Boolean)vecCompletable.elementAt(i)).booleanValue();

      if(!blnNext) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        vecMessages.addElement("Unable to complete job \""+sjNext.getName()+"\" with chosen criteria.");
      }
    }

    String strMessages[]=new String[vecMessages.size()];
    for(int i=0;i<strMessages.length;i++)
      strMessages[i]=(String)vecMessages.elementAt(i);

    return strMessages;
  }

  public Vector createArrangements() {
    Vector vecAvailableWorkersJobs=getAvailableWorkersJobs();

    return populateArrangements(vecAvailableWorkersJobs);
  }

  public Vector getAvailableWorkersJobs() {
    Vector vecAvailableWorkersJobs=new Vector();

    Vector vecJobCollection=collection.getJobCollection();

    for(int iz=0;iz<vecAvailableWorkers.size();iz++) {
      Worker workerNext=(Worker)vecAvailableWorkers.elementAt(iz);

      Vector vecWorkerProficiencies=workerNext.getJobProficiencies();
      Vector vecJobNames=new Vector();
      Vector vecJobWorkRates=new Vector();
      Vector vecJobPayRates=new Vector();
      Vector vecAlwaysUseWorkerPayRate=new Vector();
      for(int iz2=0;iz2<vecWorkerProficiencies.size();iz2++) {
        JobProficiency jpNext=(JobProficiency)vecWorkerProficiencies.elementAt(iz2);

        Job job=jpNext.getJob();

        vecJobNames.addElement(job.getName());
        vecJobWorkRates.addElement(new Double(jpNext.getRate()));
        vecJobPayRates.addElement(new Double(jpNext.getPayRate()));
        vecAlwaysUseWorkerPayRate.addElement(new Boolean(jpNext.alwaysUseWorkerPayRate()));
      }

      Vector vecTemp=new Vector();

//      vecTemp.addElement(new Integer(0));

      for(int i=0;i<vecJobCollection.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        if(sjNext.getHalfHoursCompleted()>=sjNext.getHalfHours())
          continue;

        Vector vecDependentOn=sjNext.getDependentOn();
        int izzz=0;
        for(;izzz<vecDependentOn.size();izzz++) {
          SpecificJob sjdNext=(SpecificJob)vecDependentOn.elementAt(izzz);

          if(sjdNext.getHalfHoursCompleted()!=sjdNext.getHalfHours())
            break;
        }

        if(izzz!=vecDependentOn.size()) {
//System.out.println("dependents not completed for "+sjNext.getName());
          continue;
        }


        Job job=sjNext.getJob();
        String strJobName=job.getName();

        if(blnUseCriteria[i]) {
//if((i-1)==1)
//System.out.println("wrong use criteria");
//System.out.println("use criteria: "+(i)+", "+workerNext.getName());

          boolean blnUseWorkerPayRate=sjNext.useWorkerPayRate();

          boolean blnMustContinue=false;

          for(int ia=0;ia<vecJobNames.size();ia++) {
            String strJobNameNext=(String)vecJobNames.elementAt(ia);

            if(strJobNameNext.equals(strJobName)) {
              double dblWorkRate=((Double)vecJobWorkRates.elementAt(ia)).doubleValue();
              double dblPayRate=((Double)vecJobPayRates.elementAt(ia)).doubleValue();
              boolean blnAlwaysUseWorkerPayRate=((Boolean)vecAlwaysUseWorkerPayRate.elementAt(ia)).booleanValue();


              if(blnUseWorkRates[i]) {
                if(dblWorkRate<dblWorkRates[i]) {
//System.out.println("criteria0");
                  blnMustContinue=true;
                }
              }

              if(blnUsePayRates[i]) {
                double dblFinalPayRate=0.0d;

                if(blnAlwaysUseWorkerPayRate) {
                  dblFinalPayRate=dblPayRate;
                }
                else {
                  if(blnUseWorkerPayRate) {
                    dblFinalPayRate=dblPayRate;
                  }
                  else {
                    dblFinalPayRate=sjNext.getPayRate();
                  }
                }

                if(dblFinalPayRate>dblPayRates[i]) {
//System.out.println("criteria1");
                  blnMustContinue=true;
                }
              }


/*
              if(dblWorkRate<dblWorkRates[i]) {
                blnMustContinue=true;
              }
              else {
                double dblFinalPayRate=0.0d;

                if(blnAlwaysUseWorkerPayRate) {
                  dblFinalPayRate=dblPayRate;
                }
                else {
                  if(blnUseWorkerPayRate) {
                    dblFinalPayRate=dblPayRate;
                  }
                  else {
                    dblFinalPayRate=sjNext.getPayRate();
                  }
                }

                if(dblFinalPayRate>dblPayRates[i]) {
                  blnMustContinue=true;
                }
              }
*/


              break;
            }
          }

          if(blnMustContinue)
            continue;
        }

        if(sjNext.getMaxWorkers()>sjNext.getWorkSchedule().size()) {
          for(int ia=0;ia<vecJobNames.size();ia++) {          
            String strJobNext=(String)vecJobNames.elementAt(ia);

            if(strJobName.equals(strJobNext)) {
//if(sjNext.getJob().getName().equals("Accountant"))
//System.out.println("added job "+sjNext.getName()+" , "+strJobName+" for "+workerNext.getName());

//if(sjNext.getJob().getName().equals("Software Engineer"))
//System.out.println("added job "+sjNext.getName()+" , "+strJobName+" for "+workerNext.getName());

              vecTemp.addElement(new Integer(i));
              break;
            }
          }
        }
      }

      vecAvailableWorkersJobs.addElement(vecTemp);
    }

    return vecAvailableWorkersJobs;
  }

  public Vector populateArrangements(Vector vecAvailableWorkersJobs) {
    Vector vecReturn=new Vector();

    Vector vecJobCollection=collection.getJobCollection();

//System.out.println("before matrix map");
    MatrixMap mMap=new MatrixMap(vecAvailableWorkers, vecJobCollection, vecAvailableWorkersJobs);
//System.out.println("after matrix map");

    Vector vecMapArray=mMap.getMapArray();

    if(vecMapArray.size()==0)
      return vecReturn;

//System.out.println("before populate");
    vecReturn=populateArrangements(vecAvailableWorkersJobs, vecMapArray);
//System.out.println("after populate");

    return vecReturn;
  }


/*
  public Vector populateArrangements(Vector vecAvailableWorkersJobs) {
    Vector vecReturn=new Vector();

    Vector vecJobCollection=collection.getJobCollection();

    vecAvailableWorkersJobsCopyJobs.removeAllElements();
    for(int i=0;i<vecJobCollection.size();i++) {
      vecAvailableWorkersJobsCopyJobs.addElement(((SpecificJob)vecJobCollection.elementAt(i)).clone());
    }


//    vecAvailableWorkersJobsCopy.removeAllElements();
//    for(int i=0;i<vecAvailableWorkersJobs.size();i++) {
//      Vector vecAvailableWorkersJobsElement=(Vector)vecAvailableWorkersJobs.elementAt(i);

//        Vector vecAvailableWorkersJobsCopyElement=new Vector();

//      for(int ia=0;ia<vecAvailableWorkersJobsElement.size();ia++) {
//          vecAvailableWorkersJobsCopyElement.addElement(new Integer(((Integer)vecAvailableWorkersJobsElement.elementAt(ia)).intValue()));
//        vecAvailableWorkersJobsCopyElement.addElement(((SpecificJob)vecAvailableWorkersJobsElement.elementAt(ia)).clone());
//      }

//      vecAvailableWorkersJobsCopy.addElement(vecAvailableWorkersJobsCopyElement);
//    }


    for(int i=0;i<vecAvailableWorkersJobs.size();i++) {
      for(int ia=vecAvailableWorkersJobs.size();ia>i;ia--) {
//System.out.println("from "+i+" to "+ia);
        populateArrangements(vecReturn, vecAvailableWorkersJobs, i, ia, i, null);    
      }
    }

    return vecReturn;
  }
*/

  public Vector populateArrangements(Vector vecAvailableWorkersJobs, Vector vecMapArray) {
    Vector vecReturn=new Vector();

    Vector vecJobCollection=collection.getJobCollection();

    vecAvailableWorkersJobsCopyJobs.removeAllElements();
    for(int i=0;i<vecJobCollection.size();i++) {
      vecAvailableWorkersJobsCopyJobs.addElement(((SpecificJob)vecJobCollection.elementAt(i)).clone());
    }

    for(int i=0;i<vecMapArray.size();i++) {
      String strTree=(String)vecMapArray.elementAt(i);
//System.out.println(strTree);
      Vector vecArrangementElement=new Vector();

      vecAvailableWorkersJobsCopyJobs2.removeAllElements();
      for(int ia=0;ia<vecAvailableWorkersJobsCopyJobs.size();ia++) {
        vecAvailableWorkersJobsCopyJobs2.addElement(((SpecificJob)vecAvailableWorkersJobsCopyJobs.elementAt(ia)).clone());
      }

//System.out.println("tree: "+strTree);

      while(true) {
        String strWorkerIndex=strTree.substring(0, strTree.indexOf(","));

        int intWorkerIndex=Integer.parseInt(strWorkerIndex);

        strTree=strTree.substring(strTree.indexOf(",")+1);

        int intIndex=strTree.indexOf(":");

        if(intIndex==-1)
          intIndex=strTree.length();

        String strJobIndex=strTree.substring(0, intIndex);

        int intJobIndex=Integer.parseInt(strJobIndex);

        if(intJobIndex!=-1) {
          Vector vecAvailableWorkersJobsElement=(Vector)vecAvailableWorkersJobs.elementAt(intWorkerIndex);

          Worker worker=(Worker)vecAvailableWorkers.elementAt(intWorkerIndex);
          String strWorkerName=worker.getName();

          int intJobIndex2=((Integer)vecAvailableWorkersJobsElement.elementAt(intJobIndex)).intValue();
          SpecificJob sjNext=(SpecificJob)vecAvailableWorkersJobsCopyJobs2.elementAt(intJobIndex2);

          if(sjNext.getMaxWorkers()>sjNext.getWorkSchedule().size()) {
            int ia=0;
            for(;ia<vecArrangementElement.size();ia++) {
              SpecificJobArrangement sja=(SpecificJobArrangement)vecArrangementElement.elementAt(ia);

              String sjaName=sja.getWorkerName();

              Vector vecRestricted=worker.getRestrictedCoworkers();
              int iz=0;
              for(;iz<vecRestricted.size();iz++) {
                Worker workerNext=(Worker)vecRestricted.elementAt(iz);

                if(workerNext.getName().equals(sjaName)) {
                  break;
                }
              }

              if(iz<vecRestricted.size())
                break;
            }

            if(ia==vecArrangementElement.size()) {

//if(sjNext.getName().equals("File the Paperwork"))
//System.out.println("add arrangement for File the Paperwork");


//if(sjNext.getJob().getName().equals("Administrator"))
//System.out.println("new arrangement:"+strWorkerName+", "+sjNext.getName());

              SpecificJobArrangement sja=new SpecificJobArrangement(strWorkerName, sjNext.getName());

              vecArrangementElement.addElement(sja);

              sjNext.getWorkSchedule().addElement(new SpecificJobWorked("", -1, -1));

/*
            if(!sjNext.getName().equals("MatrixPlaceHolder")) {
              SpecificJobArrangement sja=new SpecificJobArrangement(strWorkerName, sjNext.getName());

              vecArrangementElement.addElement(sja);

//if(vecArrangementElement.size()>1)
//System.out.println("found greater than 1");

              sjNext.getWorkSchedule().addElement(new SpecificJobWorked("", -1, -1));
            }
*/
            }
          }
        }

        if(strJobIndex.length()==strTree.length()) {
          break;
        }
        else {
          strTree=strTree.substring(intIndex+1);
        }
      }

      vecReturn.addElement(vecArrangementElement);
    }

    return vecReturn;
  }

/*
  public void populateArrangements(Vector vecReturn, Vector vecAvailableWorkersJobs, int intDimensionStart, int intDimensionEnd, int intDimensionCurrent, Vector vecArrangementElement) {
    Worker worker=(Worker)vecAvailableWorkers.elementAt(intDimensionCurrent);
    String strWorkerName=worker.getName();

    Vector vecAvailableWorkersJobsElement=(Vector)vecAvailableWorkersJobs.elementAt(intDimensionCurrent);

    for(int i=0;i<vecAvailableWorkersJobsElement.size();i++) {
      if(intDimensionStart==intDimensionCurrent) {

//        vecAvailableWorkersJobs.removeAllElements();
//        for(int izz=0;izz<vecAvailableWorkersJobsCopy.size();izz++) {
//          Vector vecAvailableWorkersJobsCopyElement=(Vector)vecAvailableWorkersJobsCopy.elementAt(izz);

//          Vector vecAvailableWorkersJobsElement0=new Vector();

//          for(int izzz=0;izzz<vecAvailableWorkersJobsCopyElement.size();izzz++) {
//            vecAvailableWorkersJobsElement0.addElement(((SpecificJob)vecAvailableWorkersJobsCopyElement.elementAt(izzz)).clone());
//          }

//          vecAvailableWorkersJobs.addElement(vecAvailableWorkersJobsElement0);
//        }

//        vecAvailableWorkersJobsElement=(Vector)vecAvailableWorkersJobs.elementAt(intDimensionCurrent);


        vecAvailableWorkersJobsCopyJobs2.removeAllElements();
        for(int ia=0;ia<vecAvailableWorkersJobsCopyJobs.size();ia++) {
          vecAvailableWorkersJobsCopyJobs2.addElement(((SpecificJob)vecAvailableWorkersJobsCopyJobs.elementAt(ia)).clone());
        }

        vecArrangementElement=new Vector();
      }


      SpecificJob sjNext=(SpecificJob)vecAvailableWorkersJobsCopyJobs2.elementAt(((Integer)vecAvailableWorkersJobsElement.elementAt(i)).intValue());

      boolean blnRemoveElement=false;

      if(sjNext.getMaxWorkers()>sjNext.getWorkSchedule().size()) {
//System.out.println("new arrangement:"+strWorkerName+", "+sjNext.getName());
        SpecificJobArrangement sja=new SpecificJobArrangement(strWorkerName, sjNext.getName());

        vecArrangementElement.addElement(sja);

        sjNext.getWorkSchedule().addElement(new SpecificJobWorked("", -1, -1));

        blnRemoveElement=true;
      }

      if(intDimensionCurrent==(intDimensionEnd-1)) {
        Vector vecAEClone=new Vector();
//if(vecArrangementElement.size()==0)
//System.out.println("arrangement element size of 0");
        for(int iz=0;iz<vecArrangementElement.size();iz++)
          vecAEClone.addElement(((SpecificJobArrangement)vecArrangementElement.elementAt(iz)).clone());

        vecReturn.addElement(vecAEClone);

//if(vecArrangementElement.size()==6)
//System.out.println("arrangement 6");
//System.out.println("arrangement size: "+vecArrangementElement.size());
      }
      else {
        populateArrangements(vecReturn, vecAvailableWorkersJobs, intDimensionStart, intDimensionEnd, intDimensionCurrent+1, vecArrangementElement);
      }

      if(blnRemoveElement) {
        vecArrangementElement.removeElementAt(vecArrangementElement.size()-1);

        Vector vecWorkSchedule=sjNext.getWorkSchedule();
        vecWorkSchedule.removeElementAt(vecWorkSchedule.size()-1);
      }
    }

//System.out.println("arrangements:"+vecArrangement.size());
  }
*/

  public boolean increment(BIMBoolean bimBln) {
//System.out.println("increment start");
//System.out.println("available index: "+intAvailableIndex);
//System.out.println("arrangement size: "+vecArrangement.size());

    if(intAvailableIndex.intValue()==vecArrangement.size())
      return false;

    if(intAvailableIndex.intValue()==0) {
      collectionIncrementCopy=(SpecificJobCollection)collection.clone();
      intTotalElapsedHalfHoursCopy=new Integer(intTotalElapsedHalfHours.intValue());
      dblTotalCostCopy=new Double(dblTotalCost.doubleValue());

      vecAvailableWorkersCopy.removeAllElements();
      for(int i=0;i<vecAvailableWorkers.size();i++) {
        Worker workerNext=(Worker)vecAvailableWorkers.elementAt(i);
        vecAvailableWorkersCopy.addElement(workerNext.clone());
      }

      vecBusyWorkersCopy.removeAllElements();
      for(int i=0;i<vecBusyWorkers.size();i++) {
        Worker workerNext=(Worker)vecBusyWorkers.elementAt(i);
        vecBusyWorkersCopy.addElement(workerNext.clone());
      }
    }
    else if(intAvailableIndex.intValue()>0) {
      collection=(SpecificJobCollection)collectionIncrementCopy.clone();
      intTotalElapsedHalfHours=new Integer(intTotalElapsedHalfHoursCopy.intValue());
      dblTotalCost=new Double(dblTotalCostCopy.doubleValue());

      vecAvailableWorkers.removeAllElements();
      for(int i=0;i<vecAvailableWorkersCopy.size();i++) {
        Worker workerNext=(Worker)vecAvailableWorkersCopy.elementAt(i);
        vecAvailableWorkers.addElement(workerNext.clone());
      }

      vecBusyWorkers.removeAllElements();
      for(int i=0;i<vecBusyWorkersCopy.size();i++) {
        Worker workerNext=(Worker)vecBusyWorkersCopy.elementAt(i);
        vecBusyWorkers.addElement(workerNext.clone());
      }
    }

    setIsCompleted(false);

    Vector vecJobCollection=collection.getJobCollection();

    Vector vecArrangementElement=(Vector)vecArrangement.elementAt(intAvailableIndex.intValue());

//if(vecArrangementElement.size()==5)
//System.out.println("arrangement element of 5 found");

/*
if(intTotalElapsedHalfHours.intValue()==0) {
System.out.println("increment arrangements");
for(int i=0;i<vecArrangementElement.size();i++) {
SpecificJobArrangement sjaNext=(SpecificJobArrangement)vecArrangementElement.elementAt(i);
//if(sjaNext.getSpecificJob().equals("File the Paperwork"))
System.out.println("Arrangement "+String.valueOf(i)+" "+sjaNext.getWorkerName()+" "+sjaNext.getSpecificJob());
}
System.out.println("increment arrangements after");
}
*/

/*
if(intTotalElapsedHalfHours.intValue()==0) {
System.out.println("increment arrangements");
for(int i=0;i<vecArrangementElement.size();i++) {
SpecificJobArrangement sjaNext=(SpecificJobArrangement)vecArrangementElement.elementAt(i);
if(sjaNext.getSpecificJob().equals("Recursion2") & sjaNext.getWorkerName().equals("Matthew3"))
System.out.println("Arrangement "+String.valueOf(i)+" "+sjaNext.getWorkerName()+" "+sjaNext.getSpecificJob());
}
System.out.println("increment arrangements after");
}
*/


    boolean blnAddedJob=false;

    for(int i=0;i<vecArrangementElement.size();i++) {
      SpecificJobArrangement sja=(SpecificJobArrangement)vecArrangementElement.elementAt(i);

      

//if(sja.getSpecificJob().equals("File the Paperwork"))
//System.out.println("iterate arrangement File the Paperwork");

      String strWorkerName=sja.getWorkerName();
//if(strWorkerName.equals("Joe"))
//System.out.println("arranging for Joe");
      String strSpecificJob=sja.getSpecificJob();
      
      for(int ia=0;ia<vecAvailableWorkers.size();ia++) {
        Worker workerNext=(Worker)vecAvailableWorkers.elementAt(ia);

        if(workerNext.getName().equals(strWorkerName)) {
//if(sja.getSpecificJob().equals("File the Paperwork"))
//System.out.println("iterate arrangement File the Paperwork found worker");


          for(int iz=0;iz<vecJobCollection.size();iz++) {
            SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(iz);

            String strSpecificJobName=sjNext.getName();

            String strJobName=sjNext.getJob().getName();

/*
if(strSpecificJobName.equals("File the Paperwork")) {
if(strWorkerName.equals("Jack"))
System.out.println("File the paperwork Jack");
}
*/

            if(strSpecificJob.equals(strSpecificJobName)) {
              Vector vecWorkSchedule0=sjNext.getWorkSchedule();

              Vector vecRestrictedCoworkers=workerNext.getRestrictedCoworkers();

              boolean blnRestrictedFound=false;

              for(int izzz=0;izzz<vecRestrictedCoworkers.size();izzz++) {
                Worker coworkerNext=(Worker)vecRestrictedCoworkers.elementAt(izzz);

                for(int izz=0;izz<vecWorkSchedule0.size();izz++) {
                  SpecificJobWorked sjwNext=(SpecificJobWorked)vecWorkSchedule0.elementAt(izz);

                  String strNextWorker=sjwNext.getName();

                  if(strNextWorker.equals(coworkerNext.getName())) {
                    blnRestrictedFound=true;

                    break;
                  }
                }

                if(blnRestrictedFound)
                  break;
              }

              if(blnRestrictedFound)
                break;


              vecBusyWorkers.addElement(workerNext);
              vecAvailableWorkers.removeElementAt(ia);

              --ia;

              double dblRate=0.0d;

              Vector vecJobProficiencies=workerNext.getJobProficiencies();
              for(int izz=0;izz<vecJobProficiencies.size();izz++) {
                JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(izz);

                if(jpNext.getJob().getName().equals(strJobName)) {
                  dblRate=jpNext.getRate();

                  break;
                }
              }

              if(vecWorkSchedule0.size()==0) {
                sjNext.setRelativeJobStartTime(intTotalElapsedHalfHours.intValue());
              }

//if(sja.getSpecificJob().equals("File the Paperwork"))
//System.out.println("added worked:"+strWorkerName+" "+strJobName);

              vecWorkSchedule0.addElement(new SpecificJobWorked(strWorkerName, dblRate, intTotalElapsedHalfHours.intValue()-sjNext.getRelativeJobStartTime()));

//if(vecArrangementElement.size()==5 & vecWorkSchedule0.size()==5)
//System.out.println("arrangement element and work schedule of 5 found");

//              vecWorkSchedule0.addElement(new SpecificJobWorked(strWorkerName, dblRate, sjNext.getHalfHoursCompleted()));

              blnAddedJob=true;

              break;
            }
          }

          break;
        }
      }
    }

    intAvailableIndex=new Integer(intAvailableIndex.intValue()+1);

    if(blnAddedJob) {
      bimBln.setBln(true);
    }
    else {
//System.out.println("No job added from arrangement.");
      bimBln.setBln(false);
    }

//System.out.println("increment end");

    return true;
  }

  public void incrementTimeUntilSpecificJobFinished() {
//System.out.println("increment finish start");

    Vector vecJobCollection=collection.getJobCollection();

    setIsCompleted(false);

    boolean blnMustFinish=false;

    while(true) {
      setTotalElapsedHalfHours(getTotalElapsedHalfHours()+1);

/*
int izz=0;
for(;izz<vecJobCollection.size();izz++) {
SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(izz);

if(sjNext.getWorkSchedule().size()>0)
  break;
}

if(izz==vecJobCollection.size())
System.out.println("Looping. No open jobs.");
*/


/*
izz=0;
for(;izz<vecJobCollection.size();izz++) {
SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(izz);

int intHalfHours=sjNext.getHalfHours();

if(sjNext.getHalfHoursCompleted()!=intHalfHours)
  break;
}

if(izz==vecJobCollection.size())
System.out.println("Looping. Jobs already completed.");
*/

//System.out.println("collection size:"+vecJobCollection.size());
      for(int i=0;i<vecJobCollection.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        String strJobName=sjNext.getJob().getName();

        if(sjNext.getWorkSchedule().size()==0) {
//System.out.println("continued: "+sjNext.getName());
//System.out.println("continue0");
          continue;
        }

        double dblHalfHours=sjNext.getHalfHours();

        if(sjNext.getHalfHoursCompleted()>=dblHalfHours) {
//System.out.println("continue1");
          continue;
        }

//System.out.println("didn't continue");

        double dblRate=0.0d;

        Vector vecWorkSchedule=sjNext.getWorkSchedule();
//System.out.println("incrementTimeUntil size: "+vecWorkSchedule.size());
        for(int ia=0;ia<vecWorkSchedule.size();ia++) {
          SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

          double dblRate0=sjw.getRate();

//if(strJobName.equals("Administrator")) {
//System.out.println("single rate: "+dblRate0);
//}
//System.out.println("single rate: "+strJobName+" "+dblRate0);

          dblRate+=dblRate0;

          sjw.setWorked(sjw.getWorked()+1);
        }

//if(vecWorkSchedule.size()==1) {
//System.out.println("vecWorkSchedule size is 1: "+dblRate);
//}
//if(dblRate>25.0d)
//System.out.println("rate is greater than 25");

//        int intAdd=new Double(Math.floor(dblRate)).intValue();
//        if(intAdd==0)
//          ++intAdd;

/*
if(strJobName.equals("Software Engineer")) {
intAdd=2;
}
*/


/*
        double dblRateCheck=dblRate;
        dblRateCheck=Math.ceil(dblRateCheck);

        if((dblRate+0.0001)>dblRateCheck)
          dblRate=Math.ceil(dblRate);

        int intAdd=new Double(Math.floor(dblRate)).intValue();
        if(intAdd==0)
          ++intAdd;
*/

/*
if(intAdd==1) {
if(strJobName.equals("Software Engineer"))
System.out.println("incorrect add: "+dblRate+" "+intAdd);
}
*/

        double dblHalfHoursCompleted=sjNext.getHalfHoursCompleted()+dblRate;
//System.out.println("half hours completed:"+intHalfHoursCompleted);

        if(dblHalfHoursCompleted>=dblHalfHours) {
//System.out.println("finished job:"+sjNext.getName());

          dblHalfHoursCompleted=dblHalfHours;

          blnMustFinish=true;

          double dblCost=0.0d;

          for(int ia=0;ia<vecWorkSchedule.size();ia++) {
            SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

            String strWorkerName=sjw.getName();

            double dblHalfHoursWorked=sjw.getWorked();

            for(int iz=0;iz<vecBusyWorkers.size();iz++) {
              Worker workerNext=(Worker)vecBusyWorkers.elementAt(iz);

              if(strWorkerName.equals(workerNext.getName())) {
                double dblCostNext=0.0d;

                boolean blnUseWorkerPayRate=sjNext.useWorkerPayRate();

                if(!blnUseWorkerPayRate) {
                  Vector vecJobProficiencies=workerNext.getJobProficiencies();

                  for(int izzz=0;izzz<vecJobProficiencies.size();izzz++) {
                    JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(izzz);

                    if(jpNext.getJob().getName().equals(strJobName)) {
                      if(jpNext.alwaysUseWorkerPayRate()) {
//                        blnUseWorkerPayRate=true;

                        double dblPayRate=jpNext.getPayRate();
 
                        dblCostNext=dblPayRate*dblHalfHoursWorked;
                      }
                      else {
                        double dblPayRate=sjNext.getPayRate();

                        dblCostNext=dblPayRate*dblHalfHoursWorked;
                      }

                      break;
                    }
                  }
                }
                else {
                  Vector vecJobProficiencies=workerNext.getJobProficiencies();

                  for(int izzz=0;izzz<vecJobProficiencies.size();izzz++) {
                    JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(izzz);

                    if(jpNext.getJob().getName().equals(strJobName)) {
//                      blnUseWorkerPayRate=true;

                      double dblPayRate=jpNext.getPayRate();
 
                      dblCostNext=dblPayRate*dblHalfHoursWorked;

                      break;
                    }
                  }
                }

                dblCost+=dblCostNext;

                vecBusyWorkers.removeElementAt(iz);
//if(strWorkerName.equals("Joe"))
//System.out.println("busy worker Joe");
                vecAvailableWorkers.addElement(workerNext);

                break;
              }
            }
          }

          setTotalCost(getTotalCost()+dblCost);
        }

        sjNext.setHalfHoursCompleted(dblHalfHoursCompleted);
      }

      if(blnMustFinish)
        break;
    }

    boolean blnCompleted0=true;

    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

      if(sjNext.getHalfHoursCompleted()<sjNext.getHalfHours()) {
        blnCompleted0=false;

        break;
      }
    }

/*
if(blnCompleted0) {
for(int i=1;i<vecJobCollection.size();i++) {
  SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

  Vector vecWorkSchedule=sjNext.getWorkSchedule();
  if(vecWorkSchedule.size()==2) {
    SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(0);

    String strWorkerName=sjw.getName();

    double dblHalfHoursWorked=sjw.getWorked();

    SpecificJobWorked sjw2=(SpecificJobWorked)vecWorkSchedule.elementAt(1);

    String strWorkerName2=sjw2.getName();

    double dblHalfHoursWorked2=sjw2.getWorked();

    System.out.println("work schedule: "+sjNext.getName()+", "+strWorkerName+" and "+strWorkerName2+" , "+dblHalfHoursWorked+" : "+dblHalfHoursWorked2);
  }
}
}
*/

//if(blnCompleted0)
//System.out.println("completed");

    setIsCompleted(blnCompleted0);

//System.out.println("increment finish end");

  }

  public Object clone() {
    boolean blnUseCriteria0[]=new boolean[blnUseCriteria.length];
    System.arraycopy(blnUseCriteria, 0, blnUseCriteria0, 0, blnUseCriteria.length);

    double dblWorkRates0[]=new double[dblWorkRates.length];
    System.arraycopy(dblWorkRates, 0, dblWorkRates0, 0, dblWorkRates.length);

    double dblPayRates0[]=new double[dblPayRates.length];
    System.arraycopy(dblPayRates, 0, dblPayRates0, 0, dblPayRates.length);

    boolean blnUseWorkRates0[]=new boolean[blnUseWorkRates.length];
    System.arraycopy(blnUseWorkRates, 0, blnUseWorkRates0, 0, blnUseWorkRates.length);

    boolean blnUsePayRates0[]=new boolean[blnUsePayRates.length];
    System.arraycopy(blnUsePayRates, 0, blnUsePayRates0, 0, blnUsePayRates.length);

    WorkerPool wpClone=new WorkerPool((SpecificJobCollection)collection.clone(), blnUseCriteria0, dblWorkRates0, dblPayRates0, blnUseWorkRates0, blnUsePayRates0);

//    wpClone.collection.copyDependents();

    Vector vecAWClone=new Vector();
    for(int i=0;i<vecAvailableWorkers.size();i++)
      vecAWClone.addElement(((Worker)vecAvailableWorkers.elementAt(i)).clone());
    wpClone.setAvailableWorkers(vecAWClone);

    Vector vecBWClone=new Vector();
    for(int i=0;i<vecBusyWorkers.size();i++)
      vecBWClone.addElement(((Worker)vecBusyWorkers.elementAt(i)).clone());
    wpClone.setBusyWorkers(vecBWClone);

    wpClone.setProcessPriority(blnProcessPriority.booleanValue());

    wpClone.setProcessPriorityLimiter(dblProcessPriorityLimiter.doubleValue());

    wpClone.setAvailableIndex(intAvailableIndex.intValue());

    wpClone.setIsCompleted(isCompleted());

    wpClone.setTotalElapsedHalfHours(getTotalElapsedHalfHours());

    wpClone.setTotalCost(getTotalCost());


//    wpClone.setDidLimited(blnLimited.booleanValue());

//  Vector vecAvailableWorkersCopy=new Vector();
//  Vector vecBusyWorkersCopy=new Vector();

//  Vector vecArrangement=new Vector();  //Vector of Vectors with elements of SpecificJobArrangement
//  Integer intAvailableIndex=new Integer(0);

//  SpecificJobCollection collectionIncrementCopy=null;

//  Integer intTotalElapsedHalfHoursCopy=new Integer(0);

//  Double dblTotalCostCopy=new Double(0.0d);

//  Vector vecAvailableWorkersJobsCopyJobs=new Vector();
//  Vector vecAvailableWorkersJobsCopyJobs2=new Vector();
//  Vector vecAvailableWorkersJobsCopy=new Vector();

/*
  volatile Vector vecArrangement=new Vector();  //Vector of Vectors with elements of SpecificJobArrangement
  volatile Integer intAvailableIndex=new Integer(0);

  volatile SpecificJobCollection collection=null;
  volatile SpecificJobCollection collectionIncrementCopy=null;

  volatile Boolean blnCompleted=new Boolean(false);

  volatile Integer intTotalElapsedHalfHours=new Integer(0);
  volatile Integer intTotalElapsedHalfHoursCopy=new Integer(0);

  volatile Double dblTotalCost=new Double(0.0d);
  volatile Double dblTotalCostCopy=new Double(0.0d);

//  Boolean blnLimited=new Boolean(false);

  volatile Vector vecAvailableWorkersJobsCopyJobs=new Vector();
  volatile Vector vecAvailableWorkersJobsCopyJobs2=new Vector();
//  Vector vecAvailableWorkersJobsCopy=new Vector();
*/


    return wpClone;
  }
}