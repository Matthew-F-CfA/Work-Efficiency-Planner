package bim.workEfficiencyPlanner;

import java.io.Serializable;

public class Job
implements Serializable, Cloneable, Comparable {
  volatile String strName="";
  volatile String strDescription="";

  volatile Double dblPayRate=new Double(10.0d);

  public Job() {
  }

  public Job(String strName, String strDescription, double dblPayRate0) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.dblPayRate=new Double(dblPayRate0);
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public double getPayRate() {
    return dblPayRate.doubleValue();
  }

  public void setPayRate(double dblPayRate0) {
    this.dblPayRate=new Double(dblPayRate0);
  }

  public Object clone() {
    Job jClone=new Job(strName.toString(), strDescription.toString(), getPayRate());

    return jClone;
  }

  public int compareTo(Object obj) {
    Job objJob=(Job)obj;

    return strName.compareTo(objJob.getName());
  }
}