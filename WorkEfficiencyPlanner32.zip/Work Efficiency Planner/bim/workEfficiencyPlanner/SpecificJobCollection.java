package bim.workEfficiencyPlanner;

import java.util.Vector;
import java.io.Serializable;
import java.io.IOException;
import java.io.ObjectInputStream;

public class SpecificJobCollection
implements Serializable, Cloneable {
  volatile String strName="";
  volatile String strDescription="";

  volatile Vector vecJobCollection=new Vector();

  volatile transient Vector vecJobPrioritized=new Vector(); //Vector of Vectors containing elements of SpecificJob
  volatile transient Vector vecJobPrioritizedDependentCount=new Vector(); //elements of Integer corresponding to the dependent count for elements in vecJobCollection

  public SpecificJobCollection() {
  }

  public SpecificJobCollection(String strName, String strDescription) {
    this.strName=strName;
    this.strDescription=strDescription;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public Vector getJobCollection() {
    return vecJobCollection;
  }

  public void setJobCollection(Vector vecJobCollection) {
    this.vecJobCollection=vecJobCollection;
  }

  public void addSpecificJob(SpecificJob specificJob) {
    int i=0;

    for(;i<vecJobCollection.size();i++) {
      SpecificJob specificJobNext=(SpecificJob)vecJobCollection.elementAt(i);

      if(specificJob.getName().equals(specificJobNext.getName())) {
        break;
      }
    }

    if(i==vecJobCollection.size()) {
      vecJobCollection.addElement(specificJob);
    }
  }

  public void removeSpecificJob(SpecificJob specificJob) {
    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob specificJobNext=(SpecificJob)vecJobCollection.elementAt(i);

      if(specificJob.getName().equals(specificJobNext.getName())) {
        vecJobCollection.removeElementAt(i);
        --i;
      }
    }
  }

  public Vector getJobPrioritized() {
    return vecJobPrioritized;
  }

  public void setJobPrioritized(Vector vecJobPrioritized) {
    this.vecJobPrioritized=vecJobPrioritized;
  }

  public Vector getJobPrioritizedDependentCount() {
    return vecJobPrioritizedDependentCount;
  }

  public void setJobPrioritizedDependentCount(Vector vecJobPrioritizedDependentCount) {
    this.vecJobPrioritizedDependentCount=vecJobPrioritizedDependentCount;
  }
  
  public SpecificJob findSpecificJob(String strJobName) {
    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

      if(sjNext.getName().equals(strJobName))
        return sjNext;
    }

    return null;
  }

  public void compileJobPrioritized() {
    vecJobPrioritizedDependentCount.removeAllElements();
    for(int i=0;i<vecJobCollection.size();i++)
      vecJobPrioritizedDependentCount.addElement(new Integer(0));

    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

      Vector vecDependentOn=sjNext.getDependentOn();
      for(int ia=0;ia<vecDependentOn.size();ia++) {
        SpecificJob sjNext2=(SpecificJob)vecDependentOn.elementAt(ia);

        for(int iz=0;iz<vecJobCollection.size();iz++) {
          SpecificJob sjNext3=(SpecificJob)vecJobCollection.elementAt(iz);

          if(sjNext2.getName().equals(sjNext3.getName())) {
            int intCount=((Integer)vecJobPrioritizedDependentCount.elementAt(iz)).intValue();

            ++intCount;

            vecJobPrioritizedDependentCount.setElementAt(new Integer(intCount), iz);

            break;
          }
        }
      }
    }

    vecJobPrioritized.removeAllElements();

    int intIgnoreMax=Integer.MAX_VALUE;
    int intHighCount=-1;
    Vector vecHighIndices=new Vector();
    while(true) {
      for(int i=0;i<vecJobPrioritizedDependentCount.size();i++) {
        int intNext=((Integer)vecJobPrioritizedDependentCount.elementAt(i)).intValue();

        if(intNext>=intIgnoreMax)
          continue;

        if(intNext>intHighCount) {
          intHighCount=intNext;

          vecHighIndices.removeAllElements();
          vecHighIndices.addElement(new Integer(i));
        }
        else if(intNext==intHighCount) {
          vecHighIndices.addElement(new Integer(i));
        }
      }

      Vector vecJobPrioritizedElement=new Vector();

      for(int i=0;i<vecHighIndices.size();i++) {
        int indNext=((Integer)vecHighIndices.elementAt(i)).intValue();

        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(indNext);

        vecJobPrioritizedElement.addElement(sjNext);
      }

      vecJobPrioritized.addElement(vecJobPrioritizedElement);

      if(intHighCount==0)
        break;

      intIgnoreMax=intHighCount;
      intHighCount=-1;
      vecHighIndices.removeAllElements();
    }
  }

  private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    ois.defaultReadObject();

    vecJobPrioritized=new Vector();
    vecJobPrioritizedDependentCount=new Vector();
  }

  public void copyDependents() {
    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

      sjNext.copyDependents(vecJobCollection);
    }
  }

  public Object clone() {
    SpecificJobCollection sjcClone=new SpecificJobCollection(strName.toString(), strDescription.toString());

    Vector vecJCClone=new Vector();
    for(int i=0;i<vecJobCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

      vecJCClone.addElement(sjNext.clone());
    }
    sjcClone.setJobCollection(vecJCClone);

    sjcClone.copyDependents();

    sjcClone.setJobPrioritized(getJobPrioritized());
    sjcClone.setJobPrioritizedDependentCount(getJobPrioritizedDependentCount());

    return sjcClone;
  }
}