package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;
import bim.workEfficiencyPlanner.BIMSaveDialog;

public class MainFrameJobCollection extends Frame
implements ActionListener, ItemListener {
  List lstJobs=new List(10);
  Button btnRemoveJob=new Button("Remove Specific Job");
  Button btnAddJob=new Button("Add Specific Job");
  List lstJobDependencies=new List(10);

  TextArea txtDescription=new TextArea(5, 100);

  Button btnSaveJobCollection=new Button("Save Job Collection");
  Button btnLoadJobCollection=new Button("Load Job Collection");

  Vector vecJobs=new Vector();

  SpecificJobCollection collection=new SpecificJobCollection();


  public static void main(String args[]) {
    MainFrameJobCollection mFrame=new MainFrameJobCollection();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    try {
      File fileJobs=new File("Jobs");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileJobs));
      mFrame.vecJobs=(Vector)ois.readObject();
      ois.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  MainFrameJobCollection() {
    super();

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new GridLayout(2, 1));
    Panel pnlTempA=new Panel();
    pnlTempA.setLayout(new BorderLayout());
    pnlTempA.add("North", new Label("Specific Jobs"));
    pnlTempA.add("Center", lstJobs);
    lstJobs.addItemListener(this);
    Panel pnlTempA1=new Panel();
    pnlTempA1.add(btnAddJob);
    btnAddJob.addActionListener(this);
    pnlTempA1.add(btnRemoveJob);
    btnRemoveJob.addActionListener(this);
    pnlTempA.add("South", pnlTempA1);
    pnlTemp.add(pnlTempA);
    Panel pnlTempB=new Panel();
    pnlTempB.setLayout(new BorderLayout());
    pnlTempB.add("North", new Label("Dependencies"));
    pnlTempB.add("Center", lstJobDependencies);
    lstJobDependencies.addItemListener(this);
    lstJobDependencies.setMultipleMode(true);
    pnlTemp.add(pnlTempB);

    add("Center", pnlTemp);

    Panel pnlTemp2Z=new Panel();
    pnlTemp2Z.setLayout(new BorderLayout());
    pnlTemp2Z.add("Center", txtDescription);

    Panel pnlTemp2=new Panel();
    pnlTemp2.add(btnSaveJobCollection);
    btnSaveJobCollection.addActionListener(this);
    pnlTemp2.add(btnLoadJobCollection);
    btnLoadJobCollection.addActionListener(this);
    pnlTemp2Z.add("South", pnlTemp2);

    add("South", pnlTemp2Z);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnAddJob) {
      AddSpecificJobDialog aDialog=new AddSpecificJobDialog(this);
      aDialog.show();

      if(aDialog.cancelIt)
        return;

      SpecificJob specificJob=aDialog.getSpecificJob();

      collection.addSpecificJob(specificJob);

      lstJobs.add(specificJob.getName()+" , "+specificJob.getJob().getName()+" , "+specificJob.getHalfHours()+" , "+specificJob.getMaxWorkers());
      lstJobDependencies.add(specificJob.getName());

      lstJobs.select(lstJobs.getItemCount()-1);

      txtDescription.setText(specificJob.toString());
    }
    else if(evSource==btnRemoveJob) {
      int intSelectedIndex=lstJobs.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      Vector vecJobCollection=collection.getJobCollection();

      vecJobCollection.removeElementAt(intSelectedIndex);

      String strJobName=lstJobs.getItem(intSelectedIndex);

      lstJobs.remove(intSelectedIndex);
      lstJobDependencies.remove(intSelectedIndex);

      for(int i=0;i<vecJobCollection.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        Vector vecDependentOn=sjNext.getDependentOn();

        for(int ia=0;ia<vecDependentOn.size();ia++) {
          SpecificJob sjNext0=(SpecificJob)vecDependentOn.elementAt(ia);

          if(sjNext0.getName().equals(strJobName)) {
            vecDependentOn.removeElementAt(ia);

            break;
          }
        }
      }

      lstJobs.select(-1);

      for(int i=0;i<lstJobDependencies.getItemCount();i++)
        lstJobDependencies.deselect(i);
    }
    else if(evSource==btnSaveJobCollection) {
      BIMSaveDialog sDialog=new BIMSaveDialog(this, ".saved");
      sDialog.show();

      if(sDialog.cancelIt)
        return;

      String strSaveName=sDialog.getSaveName()+".saved";

      collection.setName(sDialog.getSaveName());

//System.out.println("size: "+collection.getJobCollection().size());

      try {
        File fileSave=new File(strSaveName);
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileSave));
        oos.writeObject(collection);
        oos.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnLoadJobCollection) {
      BIMLoadDialog lDialog=new BIMLoadDialog(this, ".saved");
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      String strLoadName=lDialog.getLoadName()+".saved";

      try {
        File fileLoad=new File(strLoadName);
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
        collection=(SpecificJobCollection)ois.readObject();
        ois.close();

        lstJobs.removeAll();
        lstJobDependencies.removeAll();
        Vector vecSpecificJobs=collection.getJobCollection();
        for(int i=0;i<vecSpecificJobs.size();i++) {
          SpecificJob sjNext=(SpecificJob)vecSpecificJobs.elementAt(i);

          lstJobs.add(sjNext.getName()+" , "+sjNext.getJob().getName()+" , "+sjNext.getHalfHours()+" , "+sjNext.getMaxWorkers());
          lstJobDependencies.add(sjNext.getName());
        }


/*
        String strJobNames[]=lstJobs.getItems();

        for(int i=0;i<vecSpecificJobs.size();i++) {
          SpecificJob sjNext=(SpecificJob)vecSpecificJobs.elementAt(i);

          Vector vecDependentOn=sjNext.getDependentOn();
          for(int ia=0;ia<vecDependentOn.size();ia++) {
            SpecificJob sjNext0=(SpecificJob)vecDependentOn.elementAt(ia);

            String strDependency=sjNext0.getName();

            for(int iz=0;iz<strJobNames.length;iz++) {
              if(strDependency.equals(strJobNames[iz])) {
                lstJobDependencies.select(iz);

                break;
              }
            }
          }
        }
*/
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }

  public void itemStateChanged(ItemEvent ie) {
    Object evSource=ie.getSource();

    if(evSource==lstJobs) {
      int intSelectedIndex=lstJobs.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      lstJobDependencies.removeItemListener(this);

      for(int i=0;i<lstJobDependencies.getItemCount();i++)
        lstJobDependencies.deselect(i);

      SpecificJob specificJob=(SpecificJob)collection.getJobCollection().elementAt(intSelectedIndex);

      Vector vecDependentOn=specificJob.getDependentOn();

      String strDependencies[]=lstJobDependencies.getItems();

      for(int i=0;i<vecDependentOn.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecDependentOn.elementAt(i);

        for(int ia=0;ia<strDependencies.length;ia++) {
          if(sjNext.getName().equals(strDependencies[ia])) {
            lstJobDependencies.select(ia);

            break;
          }
        }
      }

      lstJobDependencies.addItemListener(this);

      txtDescription.setText(specificJob.toString());
    }
    else if(evSource==lstJobDependencies) {
      int intSelectedIndex0=lstJobs.getSelectedIndex();
      int intSelectedIndex=Integer.parseInt(String.valueOf(ie.getItem()));

      if(intSelectedIndex0==-1) {
        if(lstJobDependencies.isIndexSelected(intSelectedIndex)) {
          lstJobDependencies.deselect(intSelectedIndex);
        }
        else {
          lstJobDependencies.select(intSelectedIndex);
        }

        return;
      }

      if(intSelectedIndex==-1)
        return;

      if(intSelectedIndex0==intSelectedIndex) {
        lstJobDependencies.deselect(intSelectedIndex);

        return;
      }

      String strDependencyName=lstJobDependencies.getItem(intSelectedIndex);

      SpecificJob specificJobD=collection.findSpecificJob(strDependencyName);

      SpecificJob specificJob=(SpecificJob)collection.getJobCollection().elementAt(intSelectedIndex0);

      if(lstJobDependencies.isIndexSelected(intSelectedIndex)) {
        Vector vecDependentOn=specificJobD.getDependentOn();

        for(int i=0;i<vecDependentOn.size();i++) {
          SpecificJob sjNext=(SpecificJob)vecDependentOn.elementAt(i);

          if(sjNext.getName().equals(specificJob.getName())) {
            lstJobDependencies.deselect(intSelectedIndex);

            return;
          }
        }

        specificJob.addDependentOn(specificJobD);
      }
      else {
        specificJob.removeDependentOn(specificJobD);
      }
    }
  }

  class AddSpecificJobDialog extends Dialog
  implements ActionListener {
    TextField txtJobName=new TextField();
    TextField txtJobHalfHours=new TextField();
    TextField txtJobPayRate=new TextField();
    Checkbox cbUseWorkerPayRate=new Checkbox("Use worker pay rate", true);
    TextField txtJobMaxWorkers=new TextField();
    List lstJob=new List(5);
    TextArea txtJobDescription=new TextArea(5, 100);

    Button btnAddSpecificJob=new Button("Add Specific Job");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    SpecificJob specificJob=null;


    AddSpecificJobDialog(Frame parent) {
      super(parent, "Add Specific Job Dialog", true);

      for(int i=0;i<vecJobs.size();i++) {
        Job job=(Job)vecJobs.elementAt(i);

        lstJob.add(job.getName());
      }

      setLayout(new BorderLayout());

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(5, 2));
      pnlTemp.add(new Label("Job Name:"));
      pnlTemp.add(txtJobName);
      pnlTemp.add(new Label("Half Hours to Complete Job:"));
      pnlTemp.add(txtJobHalfHours);
      pnlTemp.add(new Label("Pay Rate:"));
      pnlTemp.add(txtJobPayRate);
      pnlTemp.add(cbUseWorkerPayRate);
      pnlTemp.add(new Label(""));
      pnlTemp.add(new Label("Max Workers:"));
      pnlTemp.add(txtJobMaxWorkers);
      add("North", pnlTemp);

      Panel pnlTemp2=new Panel();
      pnlTemp2.setLayout(new GridLayout(2, 1));
      pnlTemp2.add(lstJob);
      pnlTemp2.add(txtJobDescription);
      add("Center", pnlTemp2);

      Panel pnlTemp3=new Panel();
      pnlTemp3.add(btnAddSpecificJob);
      btnAddSpecificJob.addActionListener(this);
      pnlTemp3.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp3);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public SpecificJob getSpecificJob() {
      return specificJob;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddSpecificJob) {
        int intSelectedIndex=lstJob.getSelectedIndex();

        if(intSelectedIndex==-1)
          return;

        String strName=txtJobName.getText();

        if(strName.length()==0) {
          txtJobName.setText("Error. Job name is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobName.setText("");

          return;
        }

        String strDescription=txtJobDescription.getText();

        String strHalfHours=txtJobHalfHours.getText();

        if(strHalfHours.length()==0) {
          txtJobHalfHours.setText("Error. Half hours to complete job is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobHalfHours.setText("");

          return;
        }

        double dblHalfHours=0.0d;

        try {
          dblHalfHours=Double.valueOf(strHalfHours).doubleValue();

          if(dblHalfHours<1.0d)
            throw new Exception("");
        }
        catch(Exception ex) {
          txtJobHalfHours.setText("Error. Must be a positive number 1.0 or greater.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtJobHalfHours.setText(strHalfHours);

          return;
        }

        String strPayRate=txtJobPayRate.getText();

        if(strPayRate.length()==0) {
          txtJobPayRate.setText("Error. Pay rate is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobPayRate.setText("");

          return;
        }

        double dblPayRate=0.0d;

        try {
          dblPayRate=Double.valueOf(strPayRate).doubleValue();
        }
        catch(Exception ex) {
          txtJobPayRate.setText("Error. Pay rate must be a number.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtJobPayRate.setText(strPayRate);

          return;
        }

        if(dblPayRate<=0.0d) {
          txtJobPayRate.setText("Error. Pay rate must be higher than 0.0 .");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobPayRate.setText(strPayRate);

          return;
        }

        String strMaxWorkers=txtJobMaxWorkers.getText();

        if(strMaxWorkers.length()==0) {
          txtJobMaxWorkers.setText("Error. Max workers is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobMaxWorkers.setText("");

          return;
        }

        int intMaxWorkers=-1;

        try {
          intMaxWorkers=Integer.parseInt(strMaxWorkers);
        }
        catch(Exception ex) {
          txtJobMaxWorkers.setText("Error. Max workers must be a number.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtJobMaxWorkers.setText(strMaxWorkers);

          return;
        }

        if(intMaxWorkers<1) {
          txtJobMaxWorkers.setText("Error. Max workers must be 1 or greater.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtJobMaxWorkers.setText(strMaxWorkers);

          return;
        }

        boolean blnUseWorkerPayRate=cbUseWorkerPayRate.getState();

        Job job=(Job)vecJobs.elementAt(intSelectedIndex);

        specificJob=new SpecificJob(strName, strDescription, dblHalfHours, dblPayRate, job, intMaxWorkers);

        specificJob.setUseWorkerPayRate(blnUseWorkerPayRate);

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }
  }
}