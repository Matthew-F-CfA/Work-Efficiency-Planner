package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Arrays;

public class MainFramePlanner extends Frame
implements ActionListener, ItemListener {
  volatile MainFramePlanner refThis=null;
  volatile Button btnLoadJobCollection=new Button("Load Job Collection");
  volatile Label lblJobCollection=new Label("                                                                                                           ");
  volatile List lstWorkers=new List(5);
  volatile Button btnAddWorker=new Button("Add Worker");
  volatile Button btnLoadWorkerBatch=new Button("Load Worker Batch");
  volatile List lstChosenWorkers=new List(5);
  volatile Button btnClearWorkers=new Button("Clear Workers");
  volatile Button btnRemoveWorker=new Button("Remove Worker");

  volatile CheckboxGroup cbgProcessPriority=new CheckboxGroup();
  volatile Checkbox cbProcessPriorityFastestTime=new Checkbox("Fastest Time", true, cbgProcessPriority);
  volatile Checkbox cbProcessPriorityLowestCost=new Checkbox("Lowest Cost", false, cbgProcessPriority);

  volatile TextField txtProcessPriorityFastestTimeMaxCost=new TextField();
  volatile TextField txtProcessPriorityLowestCostMaxTime=new TextField();

  volatile Button btnProcessJobCollection=new Button("Process Job Collection");

  volatile Button btnOutputWorkPlan=new Button("Output Work Plan to HTML File");

  volatile List lstJobOutput=new List(10);
  volatile TextArea txtWorkerOutput=new TextArea(5, 100);
  volatile List lstWorkerPay=new List(5);
  volatile Label lblTotalEstimatedWorkTime=new Label("                                            ");
  volatile Label lblTotalEstimatedWorkCost=new Label("                                            ");
  volatile Label lblWorkerPay=new Label("                                         ");

  volatile Vector vecJobOutput=new Vector();

  volatile Hashtable hashWorkerPay=new Hashtable();

  volatile Vector vecWorkers=new Vector();

  volatile SpecificJobCollection collection=null;

  volatile Vector vecChosenWorkers=new Vector();

  volatile boolean blnLimited=false;

  volatile ProcessTrackerDialog pDialog=null;

  volatile int intProcessTrackerStatus=0;

  static int CONTINUE_PROCESSING=0;
  static int RETURN_RESULT_NOW=1;

  volatile String strProcessMessage[]=new String[0];

  volatile boolean blnProcessing=false;

//volatile int intLowestTotalElapsedHalfHours=Integer.MAX_VALUE;

  volatile boolean blnUseCriteria[]=new boolean[0];

  volatile double dblWorkRates[]=new double[0];

  volatile double dblPayRates[]=new double[0];

  volatile boolean blnUseWorkRates[]=new boolean[0];

  volatile boolean blnUsePayRates[]=new boolean[0];

//volatile double dblLowestFound=Double.MAX_VALUE;


  public static void main(String args[]) {
    MainFramePlanner mFrame=new MainFramePlanner();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    try {
      File fileWorkers=new File("Workers");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileWorkers));
      mFrame.vecWorkers=(Vector)ois.readObject();
      ois.close();

      for(int i=0;i<mFrame.vecWorkers.size();i++) {
        Worker workerNext=(Worker)mFrame.vecWorkers.elementAt(i);

        mFrame.lstWorkers.add(workerNext.getName());
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  MainFramePlanner() {
    super("Planner");

    refThis=this;

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new BorderLayout());
    Panel pnlTempA=new Panel();
    pnlTempA.add(btnLoadJobCollection);
    btnLoadJobCollection.addActionListener(this);
    pnlTempA.add(new Label("Loaded Job Collection:"));
    pnlTempA.add(lblJobCollection);
    pnlTemp.add("North", pnlTempA);

    Panel pnlTempZ=new Panel();
    pnlTempZ.setLayout(new GridLayout(1, 2));

    Panel pnlTempB=new Panel();
    pnlTempB.setLayout(new BorderLayout());
    pnlTempB.add("North", new Label("Available Workers:"));
    pnlTempB.add("Center", lstWorkers);
    Panel pnlTempB1=new Panel();
    pnlTempB1.add(btnLoadWorkerBatch);
    btnLoadWorkerBatch.addActionListener(this);
    pnlTempB1.add(btnAddWorker);
    btnAddWorker.addActionListener(this);
    pnlTempB.add("South", pnlTempB1);
    pnlTempZ.add(pnlTempB);

    Panel pnlTempE=new Panel();
    pnlTempE.setLayout(new BorderLayout());
    pnlTempE.add("North", new Label("Chosen Workers:"));
    pnlTempE.add("Center", lstChosenWorkers);
    Panel pnlTempE1=new Panel();
    pnlTempE1.add(btnClearWorkers);
    btnClearWorkers.addActionListener(this);
    pnlTempE1.add(btnRemoveWorker);
    btnRemoveWorker.addActionListener(this);
    pnlTempE.add("South", pnlTempE1);
    pnlTempZ.add(pnlTempE);

    pnlTemp.add("Center", pnlTempZ);

    Panel pnlTempZC=new Panel();
    pnlTempZC.setLayout(new GridLayout(4, 1));
    Panel pnlTempZC1=new Panel();
    pnlTempZC1.add(cbProcessPriorityFastestTime);
    cbProcessPriorityFastestTime.addItemListener(this);
    pnlTempZC1.add(cbProcessPriorityLowestCost);
    cbProcessPriorityLowestCost.addItemListener(this);
    pnlTempZC.add(pnlTempZC1);
    Panel pnlTempZC2=new Panel();
    pnlTempZC2.setLayout(new GridLayout(1, 2));
    pnlTempZC2.add(new Label("Max cost for fastest time:"));
    pnlTempZC2.add(txtProcessPriorityFastestTimeMaxCost);
    pnlTempZC.add(pnlTempZC2);
    Panel pnlTempZC3=new Panel();
    pnlTempZC3.setLayout(new GridLayout(1, 2));
    pnlTempZC3.add(new Label("Max time for lowest cost:"));
    pnlTempZC3.add(txtProcessPriorityLowestCostMaxTime);
    txtProcessPriorityLowestCostMaxTime.setEditable(false);
    pnlTempZC.add(pnlTempZC3);
    Panel pnlTempC=new Panel();
    pnlTempC.add(btnProcessJobCollection);
    btnProcessJobCollection.addActionListener(this);
    pnlTempC.add(btnOutputWorkPlan);
    btnOutputWorkPlan.addActionListener(this);
    pnlTempZC.add(pnlTempC);
    pnlTemp.add("South", pnlTempZC);

    add("North", pnlTemp);

    Panel pnlTemp2=new Panel();
    pnlTemp2.setLayout(new BorderLayout());
    pnlTemp2.add("North", new Label("Output:"));
    pnlTemp2.add("Center", lstJobOutput);
    lstJobOutput.addItemListener(this);
    Panel pnlTemp2A=new Panel();
    pnlTemp2A.setLayout(new BorderLayout());
    pnlTemp2A.add("Center", txtWorkerOutput);
    Panel pnlTemp2AZ=new Panel();
    pnlTemp2AZ.setLayout(new GridLayout(2, 1));
    Panel pnlTemp2A1=new Panel();
    pnlTemp2A1.setLayout(new BorderLayout());
    pnlTemp2A1.add("West", new Label("Total Estimated Work Time:"));
    pnlTemp2A1.add("Center", lblTotalEstimatedWorkTime);
    pnlTemp2AZ.add(pnlTemp2A1);
    Panel pnlTemp2A2=new Panel();
    pnlTemp2A2.setLayout(new BorderLayout());
    pnlTemp2A2.add("West", new Label("Total Estimated Work Cost:"));
    pnlTemp2A2.add("Center", lblTotalEstimatedWorkCost);
    pnlTemp2AZ.add(pnlTemp2A2);
    pnlTemp2A.add("South", pnlTemp2AZ);
    pnlTemp2.add("South", pnlTemp2A);

    add("Center", pnlTemp2);

    Panel pnlTemp3=new Panel();
    pnlTemp3.setLayout(new BorderLayout());
    pnlTemp3.add("North", new Label("Total Worker Pay for All Jobs: "));
    pnlTemp3.add("Center", lstWorkerPay);
    lstWorkerPay.addItemListener(this);
    Panel pnlTemp3A=new Panel();
    pnlTemp3A.setLayout(new BorderLayout());
    pnlTemp3A.add("West", new Label("Pay: "));
    pnlTemp3A.add("Center", lblWorkerPay);
    pnlTemp3.add("South", pnlTemp3A);

    add("South", pnlTemp3);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnLoadJobCollection) {
      BIMLoadDialog lDialog=new BIMLoadDialog(this, ".saved");
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      String strLoadName=lDialog.getLoadName()+".saved";

      try {
        File fileLoad=new File(strLoadName);
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
        collection=(SpecificJobCollection)ois.readObject();
        ois.close();

        lblJobCollection.setText(collection.getName());

        collection.copyDependents();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnLoadWorkerBatch) {
      BIMLoadDialog lDialog=new BIMLoadDialog(this, ".batch");
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      String strLoadName=lDialog.getLoadName()+".batch";

      try {
        File fileLoad=new File(strLoadName);
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
        Vector vecWorkerBatch=(Vector)ois.readObject();
        ois.close();

        for(int i=0;i<vecWorkerBatch.size();i++) {
          Worker workerNext=(Worker)vecWorkerBatch.elementAt(i);

          addWorker(workerNext);
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnAddWorker) {
      int intSelectedIndex=lstWorkers.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      addWorker((Worker)vecWorkers.elementAt(intSelectedIndex));
    }
    else if(evSource==btnRemoveWorker) {
      int intSelectedIndex=lstChosenWorkers.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      vecChosenWorkers.removeElementAt(intSelectedIndex);

      lstChosenWorkers.remove(intSelectedIndex);
    }
    else if(evSource==btnClearWorkers) {
      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      vecChosenWorkers.removeAllElements();

      lstChosenWorkers.removeAll();
    }
    else if(evSource==btnProcessJobCollection) {
      if(blnProcessing)
        return;

      lstJobOutput.removeAll();
      txtWorkerOutput.setText("");
      lblTotalEstimatedWorkTime.setText("");
      lblTotalEstimatedWorkCost.setText("");
      vecJobOutput.removeAllElements();
      lstWorkerPay.removeAll();
      lblWorkerPay.setText("");

      if(collection==null) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must load a job collection.");
        bDialog.show();

        return;
      }

      if(vecChosenWorkers.size()==0) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must add at least one worker.");
        bDialog.show();

        return;
      }

      if(cbProcessPriorityFastestTime.getState()) {
        String strFastestTimeMaxCost=txtProcessPriorityFastestTimeMaxCost.getText();

        if(strFastestTimeMaxCost.length()==0) {
          BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must enter a max cost.");
          bDialog.show();

          return;
        }

        try {
          int intMaxCost=Integer.parseInt(strFastestTimeMaxCost);

          if(intMaxCost<1)
            throw new Exception("");
        }
        catch(Exception ex) {
          BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must enter a max cost that is a positive integer.");
          bDialog.show();

          return;
        }
      }
      else {
        String strLowestCostMaxTime=txtProcessPriorityLowestCostMaxTime.getText();

        if(strLowestCostMaxTime.length()==0) {
          BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must enter a max time.");
          bDialog.show();

          return;
        }

        try {
          int intMaxTime=Integer.parseInt(strLowestCostMaxTime);

          if(intMaxTime<1)
            throw new Exception("");
        }
        catch(Exception ex) {
          BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", "Error. You must enter a max time that is a positive integer.");
          bDialog.show();

          return;
        }
      }


      Vector vecJobCollection=collection.getJobCollection();

      Vector vecJobCollectionProficiency=new Vector();
      for(int i=0;i<vecJobCollection.size();i++)
        vecJobCollectionProficiency.addElement(new Boolean(false));

      for(int i=0;i<vecJobCollection.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        String strJobName=sjNext.getJob().getName();

//System.out.println("specific job name: "+strJobName);

        int ia=0;
        for(;ia<vecChosenWorkers.size();ia++) {
          Worker workerNext=(Worker)vecChosenWorkers.elementAt(ia);

/*
System.out.println("next worker: "+workerNext.getName());
Vector vecProficiencies=workerNext.getJobProficiencies();
for(int izz=0;izz<vecProficiencies.size();izz++) {
JobProficiency jpNext=(JobProficiency)vecProficiencies.elementAt(izz);
System.out.println(String.valueOf(izz)+": "+jpNext.getJob().getName()+" , "+jpNext.getRate());
}
*/

          Vector vecJobProficiencies=workerNext.getJobProficiencies();
          int iz=0;
          for(;iz<vecJobProficiencies.size();iz++) {
            JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(iz);

//System.out.println("next job proficiency: "+jpNext.getJob().getName());

            if(jpNext.getJob().getName().equals(strJobName)) {
              vecJobCollectionProficiency.setElementAt(new Boolean(true), i);

              break;
            }
          }

          if(iz<vecJobProficiencies.size()) {
            break;
          }
        }
      }

      Vector vecStrs=new Vector();

      for(int i=0;i<vecJobCollectionProficiency.size();i++) {
        boolean blnNext=((Boolean)vecJobCollectionProficiency.elementAt(i)).booleanValue();

        if(!blnNext) {
          SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

          vecStrs.addElement(String.valueOf("Missing job proficiency for job type: "+sjNext.getJob().getName()));
        }
      }

      if(vecStrs.size()>0) {
        String strMessage[]=new String[vecStrs.size()];
        for(int i=0;i<strMessage.length;i++)
          strMessage[i]=(String)vecStrs.elementAt(i);

        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", strMessage);
        bDialog.show();

        return;
      }


      JobCriteriaDialog jDialog=new JobCriteriaDialog(this);
      jDialog.show();

      if(jDialog.cancelIt)
        return;

      blnUseCriteria=jDialog.getUseCriteria();

      dblWorkRates=jDialog.getWorkRates();

      dblPayRates=jDialog.getPayRates();

      blnUseWorkRates=jDialog.getUseWorkRates();

      blnUsePayRates=jDialog.getUsePayRates();



//System.out.println("process");

      SpecificJobCollection collection0=(SpecificJobCollection)collection.clone();
      Vector vecChosenWorkers0=new Vector();
      for(int i=0;i<vecChosenWorkers.size();i++)
        vecChosenWorkers0.addElement(((Worker)vecChosenWorkers.elementAt(i)).clone());

      boolean blnFastestTime=cbProcessPriorityFastestTime.getState();

//      collection0.getJobCollection().insertElementAt(new SpecificJob("MatrixPlaceHolder", "", 1.0d, 1.0d, new Job("MatrixJobPlaceHolder", "", 10.0d), 1), 0);

      WorkerPool workerPool=new WorkerPool(collection0, blnUseCriteria, dblWorkRates, dblPayRates, blnUseWorkRates, blnUsePayRates);

      workerPool.setAvailableWorkers(vecChosenWorkers0);

      workerPool.setProcessPriority(blnFastestTime);

      String strMessage[]=workerPool.verifyJobCollectionCompletable();

      if(strMessage.length>0) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection: Not Completable", strMessage);
        bDialog.show();

        return;
      }

      intProcessTrackerStatus=CONTINUE_PROCESSING;

      strProcessMessage=new String[0];

      blnProcessing=true;

      ProcessThread pThr=new ProcessThread(workerPool, blnFastestTime, vecChosenWorkers0);

      pThr.start();

      pDialog=new ProcessTrackerDialog(this, pThr);
      pDialog.show();

//System.out.println("after show");

/*
      try {
        while(blnProcessing) {
          Thread.sleep(500l);
        }
      }
      catch(Exception ex) {
      }
*/

//System.out.println("after show0");

/*      
      if(strProcessMessage.length>0) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection: Error Finding Most Efficient", strProcessMessage);
        bDialog.show();
      }
*/
    }
    else if(evSource==btnOutputWorkPlan) {
      StringBuffer sbuf=new StringBuffer();

      String strJobCollection=lblJobCollection.getText();
      String strTotalWorkTime=lblTotalEstimatedWorkTime.getText();
      String strTotalWorkCost=lblTotalEstimatedWorkCost.getText();

      sbuf.append("<font size=\"+4\">");
      sbuf.append(strJobCollection);
      sbuf.append("</font>");

      sbuf.append("<br />");

      sbuf.append("<font size=\"+2\">");
      sbuf.append("Total Work Time: "+strTotalWorkTime);
      sbuf.append("<br />");
      sbuf.append("Total Work Cost: "+strTotalWorkCost);
      sbuf.append("</font>");

      sbuf.append("<br />");

      String strWorkerNames[]=lstWorkerPay.getItems();
      Arrays.sort(strWorkerNames);
      for(int i=0;i<strWorkerNames.length;i++) {
        double dblPayNext=((Double)hashWorkerPay.get(strWorkerNames[i])).doubleValue();

        sbuf.append(strWorkerNames[i]);
        sbuf.append(": $");
        sbuf.append(dblPayNext);
        sbuf.append("<br />");
      }

      sbuf.append("<br />");

      String strJobNames[]=lstJobOutput.getItems();

      for(int i=0;i<vecJobOutput.size();i++) {
        String strOutputNext=String.valueOf(vecJobOutput.elementAt(i));

        sbuf.append("<font size=\"+2\">");
        sbuf.append(strJobNames[i]);
        sbuf.append("</font>");
        sbuf.append("<br />");
        sbuf.append("<br />");

        strOutputNext=strOutputNext.replace("\n", "<br />");

        sbuf.append(strOutputNext);

        sbuf.append("<br />");
        sbuf.append("<br />");
        sbuf.append("<br />");
        sbuf.append("<br />");
      }

      BIMSaveDialog sDialog=new BIMSaveDialog(this, ".html");
      sDialog.show();

      if(sDialog.cancelIt)
        return;

      String strSaveName=sDialog.getSaveName()+".html";

      try {
        File fileSave=new File(strSaveName);
        RandomAccessFile raf=new RandomAccessFile(fileSave, "rw");

        raf.writeBytes("<html><head><title>"+strSaveName+"</title></head><body>");

        raf.writeBytes(sbuf.toString());

        raf.writeBytes("</body></html>");

        raf.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }

  public void itemStateChanged(ItemEvent ie) {
    Object evSource=ie.getSource();

    if(evSource==lstJobOutput) {
      int intSelectedIndex=lstJobOutput.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      txtWorkerOutput.setText(String.valueOf(vecJobOutput.elementAt(intSelectedIndex)));
    }
    else if(evSource==cbProcessPriorityFastestTime) {
      txtProcessPriorityFastestTimeMaxCost.setEditable(true);

      txtProcessPriorityLowestCostMaxTime.setText("");
      txtProcessPriorityLowestCostMaxTime.setEditable(false);
    }
    else if(evSource==cbProcessPriorityLowestCost) {
      txtProcessPriorityLowestCostMaxTime.setEditable(true);

      txtProcessPriorityFastestTimeMaxCost.setText("");
      txtProcessPriorityFastestTimeMaxCost.setEditable(false);
    }
    else if(evSource==lstWorkerPay) {
      int intSelectedIndex=lstWorkerPay.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      String strWorkerName=lstWorkerPay.getItem(intSelectedIndex);

      double dblPay=((Double)hashWorkerPay.get(strWorkerName)).doubleValue();

      lblWorkerPay.setText("$"+String.valueOf(dblPay));
    }
  }

  public void addWorker(Worker worker) {
    String strWorkerName=worker.getName();

    for(int i=0;i<vecChosenWorkers.size();i++) {
      Worker workerNext=(Worker)vecChosenWorkers.elementAt(i);

      if(workerNext.getName().equals(strWorkerName))
        return;
    }

    vecChosenWorkers.addElement(worker);

    lstChosenWorkers.add(strWorkerName);
  }

  public void findMostEfficient(WorkerPool workerPool) throws Exception {
//    SpecificJobCollection sjCollection=workerPool.getJobCollection();

//    sjCollection.compileJobPrioritized();

    blnLimited=false;

//intLowestTotalElapsedHalfHours=Integer.MAX_VALUE;

//System.out.println("find before");
    WorkerPool workerPoolFastest=doWork(workerPool, null);

//System.out.println("find after");

    if(pDialog.isVisible())
      pDialog.setVisible(false);

    pDialog.txtStatus.blnKeepAlive=false;


//System.out.println("find after0");

    if(workerPoolFastest==null) {
      if(blnLimited) {
        double dblProcessPriorityLimiter=workerPool.getProcessPriorityLimiter();

        String strLimited="";

        if(workerPool.getProcessPriority()) {
          strLimited="Max cost of "+dblProcessPriorityLimiter+" exceeded. No plan found.";
        }
        else {
          strLimited="Max time of "+dblProcessPriorityLimiter+" exceeded. No plan found.";
        }

        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Process Job Collection", strLimited);
        bDialog.show();

        return;
      }
    }

//System.out.println("find after1");

    SpecificJobCollection sjCollection=workerPoolFastest.getJobCollection();

    int intTotalElapsedHalfHours=workerPoolFastest.getTotalElapsedHalfHours();

    lblTotalEstimatedWorkTime.setText(String.valueOf((new Integer(intTotalElapsedHalfHours).doubleValue()*0.5d)));

    double dblTotalCost=workerPoolFastest.getTotalCost();

    lblTotalEstimatedWorkCost.setText("$"+String.valueOf(dblTotalCost));

//System.out.println("find after2");

    Vector vecJobCollection=sjCollection.getJobCollection();

//    Vector vecJobPrioritized=sjCollection.getJobPrioritized();

    hashWorkerPay.clear();
    lstWorkerPay.removeAll();
    for(int i=0;i<vecChosenWorkers.size();i++) {
      String strWorkerName=((Worker)vecChosenWorkers.elementAt(i)).getName();

      lstWorkerPay.add(strWorkerName);
      hashWorkerPay.put(strWorkerName, new Double(0.0d));
    }

    Vector vecJobCollection0=BIMSetSorter.sortVector(vecJobCollection, "SpecificJob");

//    lstJobOutput.removeAll();
//    vecJobOutput.removeAllElements();
    for(int i=0;i<vecJobCollection0.size();i++) {
//    for(int i=0;i<vecJobPrioritized.size();i++) {
//      Vector vecJobPrioritized2=(Vector)vecJobPrioritized.elementAt(i);
//      for(int iz=0;iz<vecJobPrioritized2.size();iz++) {
//        SpecificJob sjNext=(SpecificJob)vecJobPrioritized2.elementAt(iz);

        SpecificJob sjNext=(SpecificJob)vecJobCollection0.elementAt(i);

//        if(sjNext.getName().equals("MatrixPlaceHolder"))
//          continue;

        lstJobOutput.add(sjNext.getName());

        StringBuffer sbuf=new StringBuffer();

//        sbuf.append(sjNext.getName());

//        sbuf.append("\n");

        sbuf.append("Hours into job collection:\n");

        sbuf.append(String.valueOf((new Integer(sjNext.getRelativeJobStartTime()).doubleValue()*0.5d)));

        sbuf.append("\n\n");

        Vector vecWorkSchedule=sjNext.getWorkSchedule();
        for(int ia=0;ia<vecWorkSchedule.size();ia++) {
          SpecificJobWorked sjwNext=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

          String strWorkerName=sjwNext.getName();

          Worker workerNext=null;
          for(int iz=0;iz<vecChosenWorkers.size();iz++) {
            workerNext=(Worker)vecChosenWorkers.elementAt(iz);

            if(workerNext.getName().equals(strWorkerName))
              break;
          }

          double dblWorked=sjwNext.getWorked();

          sbuf.append(sjwNext.getName()+"\n");
          sbuf.append(String.valueOf("Start Hours: "+(sjwNext.getIn()*0.5d))+"\n");
          sbuf.append(String.valueOf("Total Hours: "+(dblWorked*0.5d))+"\n");


          double dblCostNext=0.0d;

          boolean blnUseWorkerPayRate=sjNext.useWorkerPayRate();

          if(!blnUseWorkerPayRate) {
            Vector vecJobProficiencies=workerNext.getJobProficiencies();

            for(int izzz=0;izzz<vecJobProficiencies.size();izzz++) {
              JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(izzz);

              if(jpNext.getJob().getName().equals(sjNext.getJob().getName())) {
                if(jpNext.alwaysUseWorkerPayRate()) {
//                        blnUseWorkerPayRate=true;

                  double dblPayRate=jpNext.getPayRate();
 
                  dblCostNext=dblPayRate*dblWorked;
                }
                else {
                  double dblPayRate=sjNext.getPayRate();

                  dblCostNext=dblPayRate*dblWorked;
                }

                break;
              }
            }
          }
          else {
            Vector vecJobProficiencies=workerNext.getJobProficiencies();

            for(int izzz=0;izzz<vecJobProficiencies.size();izzz++) {
              JobProficiency jpNext=(JobProficiency)vecJobProficiencies.elementAt(izzz);

              if(jpNext.getJob().getName().equals(sjNext.getJob().getName())) {
//                      blnUseWorkerPayRate=true;

                double dblPayRate=jpNext.getPayRate();
 
                dblCostNext=dblPayRate*dblWorked;

                break;
              }
            }
          }

          sbuf.append("Total Pay: $"+dblCostNext+"\n\n");

          double dblCost=((Double)hashWorkerPay.get(strWorkerName)).doubleValue();
          dblCost+=dblCostNext;
          hashWorkerPay.put(strWorkerName, new Double(dblCost));
        }

        vecJobOutput.addElement(sbuf.toString());
//      }
    }

//System.out.println("find after3");

  }

  public WorkerPool doWork(WorkerPool workerPool, WorkerPool workerPoolFastest) throws Exception {
//System.out.println("doWork");

    WorkerPool workerPoolCopy=(WorkerPool)workerPool.clone();

/*
Vector vecJobCollection=workerPoolCopy.getJobCollection().getJobCollection();
for(int i=0;i<vecJobCollection.size();i++) {
SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);
if(sjNext.getHalfHoursCompleted()<sjNext.getHalfHours())
System.out.println("not completed:"+sjNext.getName());
}
*/

/*
Vector vecAvailableWorkers=workerPoolCopy.getAvailableWorkers();
for(int i=0;i<vecAvailableWorkers.size();i++) {
Worker workerNext=(Worker)vecAvailableWorkers.elementAt(i);
System.out.println("Worker:"+workerNext.getName());
}
*/

//System.out.println("elapsed half hours: "+workerPoolCopy.getTotalElapsedHalfHours());


//System.out.println("before set increment");
    workerPoolCopy.setIncrement();
//System.out.println("after set increment");

    while(true) {
      if(workerPoolCopy.getArrangement().size()==0) {
        workerPoolCopy.incrementTimeUntilSpecificJobFinished();

/*
        if(workerPoolCopy.getProcessPriority()) {
          double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

          double dblWPC=workerPoolCopy.getTotalCost();

          if(dblWPC>dblLimiter) {
            blnLimited=true;

            return workerPoolFastest;
          }
        }
        else {
          double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

          double dblWPC=new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue();

          if(dblWPC>dblLimiter) {
            blnLimited=true;

            return workerPoolFastest;
          }
        }
*/

        if(workerPoolFastest!=null) {
          if(workerPoolCopy.getProcessPriority()) {
            if(workerPoolCopy.getTotalElapsedHalfHours()>workerPoolFastest.getTotalElapsedHalfHours()) {
              return workerPoolFastest;
            }
          }
          else {
            if(workerPoolCopy.getTotalCost()>workerPoolFastest.getTotalCost()) {
              return workerPoolFastest;
            }
          }
        }

        if(workerPoolCopy.isCompleted()) {



//if(workerPoolCopy.getTotalCost()==3750.0d) {
//System.out.println("3750 hours: "+workerPoolCopy.getTotalElapsedHalfHours());
//dblLowestFound=workerPoolCopy.getTotalCost();
//System.out.println("found: "+dblLowestFound);
//}


//System.out.println("completed worker pool: "+workerPoolCopy.getTotalElapsedHalfHours());

          if(workerPoolCopy.getProcessPriority()) {
            double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

            double dblWPC=workerPoolCopy.getTotalCost();

            if(dblWPC>dblLimiter) {
              blnLimited=true;

              return workerPoolFastest;
            }
          }
          else {
            double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

            double dblWPC=new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue();

            if(dblWPC>dblLimiter) {
              blnLimited=true;

              return workerPoolFastest;
            }
          }

          if(workerPoolFastest==null) {
//System.out.println("found new fastest");
            pDialog.txtStatus.append("Found new plan:\n");
            pDialog.txtStatus.append("Time: ");
            pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
            pDialog.txtStatus.append(" Hours\n");
            pDialog.txtStatus.append("Cost: $");
            pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
            pDialog.txtStatus.append("\n\n");

            workerPoolFastest=workerPoolCopy;


            pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}

          }
          else {
            if(workerPoolCopy.getProcessPriority()) {
              if(workerPoolCopy.getTotalElapsedHalfHours()==workerPoolFastest.getTotalElapsedHalfHours()) {
                if(workerPoolCopy.getTotalCost()==workerPoolFastest.getTotalCost()) {
                  pDialog.txtStatus.append("Found new plan:\n");
                  pDialog.txtStatus.append("Time: ");
                  pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                  pDialog.txtStatus.append(" Hours\n");
                  pDialog.txtStatus.append("Cost: $");
                  pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                  pDialog.txtStatus.append("\n\n");

                  workerPoolFastest=chooseBestPlan(workerPoolCopy, workerPoolFastest);

                  pDialog.setResultFound(true);
                }
                else if(workerPoolCopy.getTotalCost()<workerPoolFastest.getTotalCost()) {
                  pDialog.txtStatus.append("Found new plan:\n");
                  pDialog.txtStatus.append("Time: ");
                  pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                  pDialog.txtStatus.append(" Hours\n");
                  pDialog.txtStatus.append("Cost: $");
                  pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                  pDialog.txtStatus.append("\n\n");

                  workerPoolFastest=workerPoolCopy;

                  pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
                }
              }
              else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours()) {
//System.out.println("found new fastest");
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=workerPoolCopy;

                pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
              }
            }
            else {
              if(workerPoolCopy.getTotalCost()==workerPoolFastest.getTotalCost()) {
                if(workerPoolCopy.getTotalElapsedHalfHours()==workerPoolFastest.getTotalElapsedHalfHours()) {
                  pDialog.txtStatus.append("Found new plan:\n");
                  pDialog.txtStatus.append("Time: ");
                  pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                  pDialog.txtStatus.append(" Hours\n");
                  pDialog.txtStatus.append("Cost: $");
                  pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                  pDialog.txtStatus.append("\n\n");

                  workerPoolFastest=chooseBestPlan(workerPoolCopy, workerPoolFastest);

                  pDialog.setResultFound(true);
                }
                else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours()) {
                  pDialog.txtStatus.append("Found new plan:\n");
                  pDialog.txtStatus.append("Time: ");
                  pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                  pDialog.txtStatus.append(" Hours\n");
                  pDialog.txtStatus.append("Cost: $");
                  pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                  pDialog.txtStatus.append("\n\n");

                  workerPoolFastest=workerPoolCopy;

                  pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
                }
              }
              else if(workerPoolCopy.getTotalCost()<workerPoolFastest.getTotalCost()) {
//System.out.println("found new fastest");
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=workerPoolCopy;

                pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
              }
            }
          }

//System.out.println("returned");

          return workerPoolFastest;        
        }

        workerPoolCopy=(WorkerPool)workerPoolCopy.clone();

        workerPoolCopy.setIncrement();
      }
      else {
        break;
      }
    }

    BIMBoolean blnBln=new BIMBoolean(true);

//System.out.println("doWorkLoop before");
    while(workerPoolCopy.increment(blnBln)) {

      if(intProcessTrackerStatus==RETURN_RESULT_NOW) {
//System.out.println("return result now0");
        return workerPoolFastest;
      }

      if(!blnBln.getBln())
        continue;

//System.out.println("finish before");
/*
      while(true) {
        workerPoolCopy.incrementTimeUntilSpecificJobFinished();

        Vector vecArrangements=workerPoolCopy.createArrangements();

        if(vecArrangements.size()>0)
          break;
      }
*/

/*
System.out.println("Jobs not completed 0");
Vector vecJobCollection=workerPoolCopy.getJobCollection().getJobCollection();
for(int i=0;i<vecJobCollection.size();i++) {
SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);
if(sjNext.getHalfHoursCompleted()!=sjNext.getHalfHours())
System.out.println(sjNext.getName());
}
System.out.println("Jobs not completed 1");
*/

      workerPoolCopy.incrementTimeUntilSpecificJobFinished();
//System.out.println("finish after");

/*
System.out.println("Jobs not completed 2");
vecJobCollection=workerPoolCopy.getJobCollection().getJobCollection();
for(int i=0;i<vecJobCollection.size();i++) {
SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);
if(sjNext.getHalfHoursCompleted()!=sjNext.getHalfHours())
System.out.println(sjNext.getName());
}
System.out.println("Jobs not completed 3");

System.out.println(workerPoolCopy.isCompleted());
*/

/*
      if(workerPoolCopy.getProcessPriority()) {
        double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

        double dblWPC=workerPoolCopy.getTotalCost();

        if(dblWPC>dblLimiter) {
          blnLimited=true;

          continue;
        }

//        if(dblWPC>dblLimiter)
//          return workerPoolFastest;
      }
      else {
        double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

        double dblWPC=new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue();

        if(dblWPC>dblLimiter) {
          blnLimited=true;

          continue;
        }

//        if(dblWPC>dblLimiter)
//          return workerPoolFastest;
      }
*/

      if(workerPoolFastest!=null) {
        if(workerPoolCopy.getProcessPriority()) {
          if(workerPoolCopy.getTotalElapsedHalfHours()>workerPoolFastest.getTotalElapsedHalfHours())
            continue;
        }
        else {
          if(workerPoolCopy.getTotalCost()>workerPoolFastest.getTotalCost())
            continue;
        }
      }

//System.out.println("didn't continue");

      if(workerPoolCopy.isCompleted()) {


//if(workerPoolCopy.getTotalCost()==3750.0d) {
//System.out.println("3750 hours0: "+workerPoolCopy.getTotalElapsedHalfHours());
//dblLowestFound=workerPoolCopy.getTotalCost();
//System.out.println("found0: "+dblLowestFound);
//}



//System.out.println("completed worker pool0: "+workerPoolCopy.getTotalElapsedHalfHours());

        if(workerPoolCopy.getProcessPriority()) {
          double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

          double dblWPC=workerPoolCopy.getTotalCost();

          if(dblWPC>dblLimiter) {
            blnLimited=true;

            continue;
          }

//        if(dblWPC>dblLimiter)
//          return workerPoolFastest;
        }
        else {
          double dblLimiter=workerPoolCopy.getProcessPriorityLimiter();

          double dblWPC=new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue();

          if(dblWPC>dblLimiter) {
            blnLimited=true;

            continue;
          }

//        if(dblWPC>dblLimiter)
//          return workerPoolFastest;
        }

        if(workerPoolFastest==null) {
//System.out.println("found new fastest");
          pDialog.txtStatus.append("Found new plan:\n");
          pDialog.txtStatus.append("Time: ");
          pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
          pDialog.txtStatus.append(" Hours\n");
          pDialog.txtStatus.append("Cost: $");
          pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
          pDialog.txtStatus.append("\n\n");

          workerPoolFastest=(WorkerPool)workerPoolCopy.clone();

          pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
        }
        else {
          if(workerPoolCopy.getProcessPriority()) {
            if(workerPoolCopy.getTotalElapsedHalfHours()==workerPoolFastest.getTotalElapsedHalfHours()) {
              if(workerPoolCopy.getTotalCost()==workerPoolFastest.getTotalCost()) {
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=chooseBestPlan((WorkerPool)workerPoolCopy.clone(), workerPoolFastest);

                pDialog.setResultFound(true);
              }
              else if(workerPoolCopy.getTotalCost()<workerPoolFastest.getTotalCost()) {
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=(WorkerPool)workerPoolCopy.clone();

                pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
              }
            }
            else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours()) {
//System.out.println("found new fastest");
              pDialog.txtStatus.append("Found new plan:\n");
              pDialog.txtStatus.append("Time: ");
              pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
              pDialog.txtStatus.append(" Hours\n");
              pDialog.txtStatus.append("Cost: $");
              pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
              pDialog.txtStatus.append("\n\n");

              workerPoolFastest=(WorkerPool)workerPoolCopy.clone();

              pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
            }
          }
          else {
            if(workerPoolCopy.getTotalCost()==workerPoolFastest.getTotalCost()) {
              if(workerPoolCopy.getTotalElapsedHalfHours()==workerPoolFastest.getTotalElapsedHalfHours()) {
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=chooseBestPlan((WorkerPool)workerPoolCopy.clone(), workerPoolFastest);

                pDialog.setResultFound(true);
              }
              else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours()) {
                pDialog.txtStatus.append("Found new plan:\n");
                pDialog.txtStatus.append("Time: ");
                pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
                pDialog.txtStatus.append(" Hours\n");
                pDialog.txtStatus.append("Cost: $");
                pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
                pDialog.txtStatus.append("\n\n");

                workerPoolFastest=(WorkerPool)workerPoolCopy.clone();

                pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
              }
            }
            else if(workerPoolCopy.getTotalCost()<workerPoolFastest.getTotalCost()) {
//System.out.println("found new fastest");
              pDialog.txtStatus.append("Found new plan:\n");
              pDialog.txtStatus.append("Time: ");
              pDialog.txtStatus.append(String.valueOf((new Integer(workerPoolCopy.getTotalElapsedHalfHours()).doubleValue()*0.5d)));
              pDialog.txtStatus.append(" Hours\n");
              pDialog.txtStatus.append("Cost: $");
              pDialog.txtStatus.append(String.valueOf(workerPoolCopy.getTotalCost()));
              pDialog.txtStatus.append("\n\n");

              workerPoolFastest=(WorkerPool)workerPoolCopy.clone();

              pDialog.setResultFound(true);

//if(workerPoolCopy.getTotalElapsedHalfHours()<intLowestTotalElapsedHalfHours) {
//intLowestTotalElapsedHalfHours=workerPoolCopy.getTotalElapsedHalfHours();
//System.out.println("new lowest elapsed: "+intLowestTotalElapsedHalfHours);
//}
            }
          }
        }

/*
        if(workerPoolFastest==null)
          workerPoolFastest=workerPoolCopy;
        else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours())
          workerPoolFastest=workerPoolCopy;
*/
//        else
//          return workerPoolFastest;
      }
      else {
        WorkerPool workerPoolCopy0=doWork(workerPoolCopy, workerPoolFastest);

        workerPoolFastest=workerPoolCopy0;

        if(intProcessTrackerStatus==RETURN_RESULT_NOW) {
//System.out.println("return result now1");
          return workerPoolFastest;
        }

/*
        if(workerPoolFastest==null) {
          workerPoolFastest=workerPoolCopy0;
        }
        else {
          if(workerPoolCopy0.getProcessPriority()) {
            if(workerPoolCopy0.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours()) {
              workerPoolFastest=workerPoolCopy0;
            }
          }
          else {
            if(workerPoolCopy0.getTotalCost()<workerPoolFastest.getTotalCost()) {
              workerPoolFastest=workerPoolCopy0;
            }
          }
        }
*/


/*
        if(workerPoolFastest==null)
          workerPoolFastest=workerPoolCopy0;
        else if(workerPoolCopy0.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours())
          workerPoolFastest=workerPoolCopy0;
*/
//        else
//          return workerPoolFastest;
      }
    }
//System.out.println("doWorkLoop after");

/*
    if(workerPoolCopy.isCompleted()) {
      if(workerPoolFastest==null)
        return workerPoolCopy;
      else if(workerPoolCopy.getTotalElapsedHalfHours()<workerPoolFastest.getTotalElapsedHalfHours())
        return workerPoolCopy;
      else
        return workerPoolFastest;
    }
    else {
      workerPoolFastest=doWork(workerPoolCopy, workerPoolFastest);

      while(workerPoolCopy.increment()) {
        workerPoolCopy.incrementTimeUntilSpecificJobFinished();

        workerPoolFastest=doWork(workerPoolCopy, workerPoolFastest);
      }
    }
*/

    return workerPoolFastest;
  }

  public WorkerPool chooseBestPlan(WorkerPool workerPool0, WorkerPool workerPool1) {
    double dblAverage0=0.0d;

    Vector vecCollection=workerPool0.getJobCollection().getJobCollection();

    for(int i=0;i<vecCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

      Vector vecWorkSchedule=sjNext.getWorkSchedule();

      double dblIn=0.0d;

      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

        double dblNextIn=sjw.getWorked();

        dblIn=dblIn+dblNextIn;
      }

      double dblAve=dblIn/new Integer(vecWorkSchedule.size()).doubleValue();

      double dblSums=0.0d;

      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

        double dblDifference=sjw.getWorked()-dblAve;

        dblDifference=Math.abs(dblDifference);

        dblSums=dblSums+dblDifference;
      }

      dblAve=dblSums/new Integer(vecWorkSchedule.size()).doubleValue();

      dblAverage0=dblAverage0+dblAve;
    }

    dblAverage0=dblAverage0/new Integer(vecCollection.size()).doubleValue();


    double dblAverage1=0.0d;

    vecCollection=workerPool1.getJobCollection().getJobCollection();

    for(int i=0;i<vecCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

      Vector vecWorkSchedule=sjNext.getWorkSchedule();

      double dblIn=0.0d;

      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

        double dblNextIn=sjw.getWorked();

        dblIn=dblIn+dblNextIn;
      }

      double dblAve=dblIn/new Integer(vecWorkSchedule.size()).doubleValue();

      double dblSums=0.0d;

      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

        double dblDifference=sjw.getWorked()-dblAve;

        dblDifference=Math.abs(dblDifference);

        dblSums=dblSums+dblDifference;
      }

      dblAve=dblSums/new Integer(vecWorkSchedule.size()).doubleValue();

      dblAverage1=dblAverage1+dblAve;
    }

    dblAverage1=dblAverage1/new Integer(vecCollection.size()).doubleValue();

    if(dblAverage0<dblAverage1)
      return workerPool0;

    return workerPool1;
  }

/*
  public WorkerPool chooseBestPlan(WorkerPool workerPool0, WorkerPool workerPool1) {
    int intTotalElapsedHalfHours=workerPool0.getTotalElapsedHalfHours();
    double dblTotalElapsedHalfHours=new Integer(intTotalElapsedHalfHours).doubleValue();

    int intChosenWorkersSize=vecChosenWorkers.size();
    double dblChosenWorkersSize=new Integer(intChosenWorkersSize).doubleValue();

    double dblAverage0=0.0d;

    Vector vecCollection=workerPool0.getJobCollection().getJobCollection();


//    for(int i=0;i<vecCollection.size();i++) {
//      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

//      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//      dblAverage0=dblAverage0+dblStartTime;
//    }



//    for(int i=0;i<vecCollection.size();i++) {
//      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

//      Vector vecWorkSchedule=sjNext.getWorkSchedule();

//      boolean blnAllZero=true;

//      double dblIn=0.0d;

//      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
//        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

//        double dblNextIn=sjw.getIn()+sjNext.getRelativeJobStartTime();

//        dblIn=dblIn+dblNextIn;

//        if(sjw.getIn()!=0.0d)
//          blnAllZero=false;
//      }

//      if(!blnAllZero) {
//        dblIn=dblIn/new Integer(vecWorkSchedule.size()).doubleValue();
      
//        double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//        dblAverage0=dblAverage0+dblStartTime-(dblStartTime*(1.0d-dblIn/dblTotalElapsedHalfHours));
//      }

//      double dblWSSize=new Integer(vecWorkSchedule.size()).doubleValue();

//      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//      dblAverage0=dblAverage0+dblStartTime-(dblStartTime*dblWSSize/dblChosenWorkersSize);
//    }


    for(int i=0;i<vecCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

      Vector vecWorkSchedule=sjNext.getWorkSchedule();

      double dblWSSize=new Integer(vecWorkSchedule.size()).doubleValue();

      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

      dblAverage0=dblAverage0+dblStartTime-(dblStartTime*(1.0d-dblWSSize/dblChosenWorkersSize));
    }


    dblAverage0=dblAverage0/new Integer(vecCollection.size()).doubleValue();


    double dblAverage1=0.0d;

    vecCollection=workerPool1.getJobCollection().getJobCollection();


//    for(int i=0;i<vecCollection.size();i++) {
//      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

//      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//      dblAverage1=dblAverage1+dblStartTime;
//    }



//    for(int i=0;i<vecCollection.size();i++) {
//      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

//      Vector vecWorkSchedule=sjNext.getWorkSchedule();

//      boolean blnAllZero=true;

//      double dblIn=0.0d;

//      for(int ia=0;ia<vecWorkSchedule.size();ia++) {
//        SpecificJobWorked sjw=(SpecificJobWorked)vecWorkSchedule.elementAt(ia);

//        double dblNextIn=sjw.getIn()+sjNext.getRelativeJobStartTime();

//        dblIn=dblIn+dblNextIn;

//        if(sjw.getIn()!=0.0d)
//          blnAllZero=false;
//      }

//      if(!blnAllZero) {
//        dblIn=dblIn/new Integer(vecWorkSchedule.size()).doubleValue();
      
//        double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//        dblAverage1=dblAverage1+dblStartTime-(dblStartTime*(1.0d-dblIn/dblTotalElapsedHalfHours));
//      }


//      double dblWSSize=new Integer(vecWorkSchedule.size()).doubleValue();

//      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

//      dblAverage1=dblAverage1+dblStartTime-(dblStartTime*dblWSSize/dblChosenWorkersSize);
//    }



    for(int i=0;i<vecCollection.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecCollection.elementAt(i);

      Vector vecWorkSchedule=sjNext.getWorkSchedule();

      double dblWSSize=new Integer(vecWorkSchedule.size()).doubleValue();

      double dblStartTime=new Integer(sjNext.getRelativeJobStartTime()).doubleValue();

      dblAverage1=dblAverage1+dblStartTime-(dblStartTime*(1.0d-dblWSSize/dblChosenWorkersSize));
    }

    dblAverage1=dblAverage1/new Integer(vecCollection.size()).doubleValue();

    if(dblAverage0<dblAverage1)
      return workerPool0;

    return workerPool1;
  }
*/

  class ProcessThread extends Thread {
    volatile WorkerPool workerPool=null;
    volatile boolean blnFastestTime=true;
    volatile Vector vecChosenWorkers0=null;

    ProcessThread(WorkerPool workerPool, boolean blnFastestTime, Vector vecChosenWorkers0) {
      super();

      this.workerPool=workerPool;
      this.blnFastestTime=blnFastestTime;
      this.vecChosenWorkers0=vecChosenWorkers0;
    }

    public void run() {
//      workerPool.setAvailableWorkers(vecChosenWorkers0);

//      workerPool.setProcessPriority(blnFastestTime);

      if(blnFastestTime) {
        double dblProcessPriorityFastestTimeMaxCost=Double.valueOf(txtProcessPriorityFastestTimeMaxCost.getText()).doubleValue();

        workerPool.setProcessPriorityLimiter(dblProcessPriorityFastestTimeMaxCost);
      }
      else {
        double dblProcessPriorityLowestCostMaxTime=Double.valueOf(txtProcessPriorityLowestCostMaxTime.getText()).doubleValue();

        workerPool.setProcessPriorityLimiter(dblProcessPriorityLowestCostMaxTime);
      }

      try {

//System.out.println("process1");
        findMostEfficient(workerPool);
//System.out.println("process2");

        blnProcessing=false;

      }
      catch(Exception ex) {
        ex.printStackTrace();

        StackTraceElement stElement[]=ex.getStackTrace();
        strProcessMessage=new String[stElement.length];

        for(int i=0;i<stElement.length;i++)
          strProcessMessage[i]=stElement[i].toString();

        BIMMessageDialog bDialog=new BIMMessageDialog(refThis, "Process Job Collection: Error Finding Most Efficient", strProcessMessage);
        bDialog.show();

        blnProcessing=false;
      }
    }
  }

  class ProcessTrackerDialog extends Dialog
  implements ActionListener {
    volatile Thread thr=null;

    volatile BIMTextAreaThread txtStatus=new BIMTextAreaThread();

    volatile Button btnReturnResultNow=new Button("Return Result Now");
    volatile Button btnCancel=new Button("Cancel");

    volatile boolean blnResultFound=false;

    ProcessTrackerDialog(Frame parent, Thread thr) {
      super(parent, "Process Tracker", true);

      this.thr=thr;

      setLayout(new BorderLayout());

      txtStatus.setText("Processing...\n\n");

      add("Center", txtStatus);

      Panel pnlTemp=new Panel();
      pnlTemp.add(btnReturnResultNow);
      btnReturnResultNow.addActionListener(this);
      btnReturnResultNow.setEnabled(false);
      pnlTemp.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", pnlTemp);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);

      new Thread(txtStatus).start();
    }

    public void setResultFound(boolean blnResultFound) {
      btnReturnResultNow.setEnabled(blnResultFound);
      btnCancel.setEnabled(!blnResultFound);

      this.blnResultFound=blnResultFound;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnReturnResultNow) {
        intProcessTrackerStatus=RETURN_RESULT_NOW;

        txtStatus.blnKeepAlive=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        intProcessTrackerStatus=RETURN_RESULT_NOW;

        txtStatus.blnKeepAlive=false;

        blnProcessing=false;

        try {
          thr.interrupt();
        }
        catch(Exception ex) {
        }

        dispose();
      }
    }
  }

  class JobCriteriaDialog extends Dialog
  implements ActionListener, ItemListener {
    volatile ScrollPane spSpecificJobs=new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
    volatile Panel pnlSpecificJobs=new Panel();
    volatile Checkbox cbSpecificJobsUseCriteria[]=new Checkbox[0];
    volatile Label lblSpecificJobsWorkerCount[]=new Label[0];
    volatile TextField txtSpecificJobsWork[]=new TextField[0];
    volatile TextField txtSpecificJobsPay[]=new TextField[0];
    volatile Checkbox cbSpecificJobsUseJobWork[]=new Checkbox[0];
    volatile Checkbox cbSpecificJobsUseJobPay[]=new Checkbox[0];
    volatile Button btnSpecificJobsSetJobWork[]=new Button[0];
    volatile Button btnSpecificJobsSetJobPay[]=new Button[0];
    volatile Button btnSpecificJobsApply[]=new Button[0];
    volatile List lstJobs=new List(5);
    volatile TextField txtWorkRate=new TextField(5);
    volatile TextField txtPayRate=new TextField(5);
    volatile Button btnApplyJobCriteria=new Button("Apply Job Criteria");
    volatile Button btnRestoreDefaultCriteria=new Button("Restore Default Criteria");

    volatile Button btnProcess=new Button("Process");
    volatile Button btnCancel=new Button("Cancel");

    volatile Label lblStatus=new Label("                                                                     ");

    volatile boolean cancelIt=false;

    volatile Vector vecJobWorkRate=new Vector();
    volatile Vector vecJobPayRate=new Vector();
    volatile Vector vecJobPayRateApplied=new Vector();

    volatile Vector vecSpecificJobsSpecificJobName=new Vector();
    volatile Vector vecSpecificJobsJobName=new Vector();
    volatile Vector vecSpecificJobsWorkRateApplied=new Vector();
    volatile Vector vecSpecificJobsPayRateApplied=new Vector();

    volatile boolean blnUseCriteria[]=new boolean[0];
    volatile double dblWorkRates[]=new double[0];
    volatile double dblPayRates[]=new double[0];
    volatile boolean blnUseWorkRates[]=new boolean[0];
    volatile boolean blnUsePayRates[]=new boolean[0];

    JobCriteriaDialog(Frame parent) {
      super(parent, "Job Criteria", true);

      setLayout(new BorderLayout());

//      txtWorkRate.setText("1.0");

      try {
        File fileJobs=new File("Jobs");
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileJobs));
        Vector vecJobs=(Vector)ois.readObject();
        ois.close();

        for(int i=0;i<vecJobs.size();i++) {
          Job jobNext=(Job)vecJobs.elementAt(i);

          lstJobs.add(jobNext.getName());

          vecJobWorkRate.addElement(new Double(1.0d));
          vecJobPayRate.addElement(new Double(jobNext.getPayRate()));
          vecJobPayRateApplied.addElement(new Double(jobNext.getPayRate()));
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new BorderLayout());
      pnlTemp.add("North", new Label("Jobs:"));
      pnlTemp.add("Center", lstJobs);
      lstJobs.addItemListener(this);
      Panel pnlTempA=new Panel();
      pnlTempA.setLayout(new GridLayout(3, 2));
      pnlTempA.add(new Label("Work Rate:"));
      pnlTempA.add(txtWorkRate);
      pnlTempA.add(new Label("Pay Rate:"));
      pnlTempA.add(txtPayRate);
      pnlTempA.add(btnApplyJobCriteria);
      btnApplyJobCriteria.addActionListener(this);
      pnlTempA.add(btnRestoreDefaultCriteria);
      btnRestoreDefaultCriteria.addActionListener(this);
      pnlTemp.add("South", pnlTempA);

      add("North", pnlTemp);

      Vector vecJobCollection=collection.getJobCollection();

      cbSpecificJobsUseCriteria=new Checkbox[vecJobCollection.size()];
      lblSpecificJobsWorkerCount=new Label[vecJobCollection.size()];
      txtSpecificJobsWork=new TextField[vecJobCollection.size()];
      txtSpecificJobsPay=new TextField[vecJobCollection.size()];
      cbSpecificJobsUseJobWork=new Checkbox[vecJobCollection.size()];
      cbSpecificJobsUseJobPay=new Checkbox[vecJobCollection.size()];
      btnSpecificJobsSetJobWork=new Button[vecJobCollection.size()];
      btnSpecificJobsSetJobPay=new Button[vecJobCollection.size()];
      btnSpecificJobsApply=new Button[vecJobCollection.size()];

      pnlSpecificJobs.setLayout(new GridLayout(vecJobCollection.size(), 1));

//System.out.println("job collection size:"+vecJobCollection.size());

      for(int i=0;i<vecJobCollection.size();i++) {
        SpecificJob sjNext=(SpecificJob)vecJobCollection.elementAt(i);

        cbSpecificJobsUseCriteria[i]=new Checkbox("Use Criteria", false);
        lblSpecificJobsWorkerCount[i]=new Label("     ");
        txtSpecificJobsWork[i]=new TextField(5);
        btnSpecificJobsSetJobWork[i]=new Button("Set to Job Type Rate");
        btnSpecificJobsSetJobWork[i].addActionListener(this);
        txtSpecificJobsPay[i]=new TextField(5);
        btnSpecificJobsSetJobPay[i]=new Button("Set to Job Type Rate");
        btnSpecificJobsSetJobPay[i].addActionListener(this);
        cbSpecificJobsUseJobWork[i]=new Checkbox("Use Work Rate", false);
        cbSpecificJobsUseJobWork[i].addItemListener(this);
        cbSpecificJobsUseJobPay[i]=new Checkbox("Use Pay Rate", false);
        cbSpecificJobsUseJobPay[i].addItemListener(this);
        btnSpecificJobsApply[i]=new Button("Apply Criteria");
        btnSpecificJobsApply[i].addActionListener(this);

        Panel pnlTempZ=new Panel();
        pnlTempZ.add(cbSpecificJobsUseCriteria[i]);
        pnlTempZ.add(new Label("Worker Count:"));
        pnlTempZ.add(lblSpecificJobsWorkerCount[i]);
        pnlTempZ.add(new Label(sjNext.getName()));
        pnlTempZ.add(new Label("Work Rate:"));
        pnlTempZ.add(txtSpecificJobsWork[i]);
        pnlTempZ.add(btnSpecificJobsSetJobWork[i]);
        pnlTempZ.add(new Label("Pay Rate:"));
        pnlTempZ.add(txtSpecificJobsPay[i]);
        pnlTempZ.add(btnSpecificJobsSetJobPay[i]);
        pnlTempZ.add(cbSpecificJobsUseJobWork[i]);
        pnlTempZ.add(cbSpecificJobsUseJobPay[i]);
        pnlTempZ.add(btnSpecificJobsApply[i]);

        pnlSpecificJobs.add(pnlTempZ);

        txtSpecificJobsWork[i].setText("1.0");
        txtSpecificJobsPay[i].setText(String.valueOf(sjNext.getPayRate()));

        vecSpecificJobsSpecificJobName.addElement(sjNext.getName());
        vecSpecificJobsJobName.addElement(sjNext.getJob().getName());
        vecSpecificJobsWorkRateApplied.addElement(new Double(1.0d));
        vecSpecificJobsPayRateApplied.addElement(new Double(sjNext.getPayRate()));
      }

      spSpecificJobs.add(pnlSpecificJobs);

      add("Center", spSpecificJobs);

      Panel pnlTemp2Z=new Panel();
      pnlTemp2Z.setLayout(new GridLayout(2, 1));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnProcess);
      btnProcess.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      pnlTemp2Z.add(pnlTemp2);
      Panel pnlTemp2Z1=new Panel();
      pnlTemp2Z1.setLayout(new BorderLayout());
      pnlTemp2Z1.add("West", new Label("Status:"));
      pnlTemp2Z1.add("Center", lblStatus);
      pnlTemp2Z.add(pnlTemp2Z1);

      add("South", pnlTemp2Z);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/10, dimScreen.height/10);
      double dblWidth=new Integer(dimScreen.width).doubleValue();
      dblWidth=dblWidth*0.8d;
      int intWidth=(int)Math.rint(dblWidth);
      double dblHeight=new Integer(dimScreen.height).doubleValue();
      dblHeight=dblHeight*0.8d;
      int intHeight=(int)Math.rint(dblHeight);
      setSize(intWidth, intHeight);

      for(int i=0;i<vecSpecificJobsSpecificJobName.size();i++)
        recalculateWorkers(i);

//      applySpecificJobsCriteria();

/*
      SpecificJobCollection collection0=(SpecificJobCollection)collection.clone();
      Vector vecChosenWorkers0=new Vector();
      for(int i=0;i<vecChosenWorkers.size();i++)
        vecChosenWorkers0.addElement(((Worker)vecChosenWorkers.elementAt(i)).clone());
*/
    }

    public boolean[] getUseCriteria() {
      return blnUseCriteria;
    }

    public double[] getWorkRates() {
      return dblWorkRates;
    }

    public double[] getPayRates() {
      return dblPayRates;
    }

    public boolean[] getUseWorkRates() {
      return blnUseWorkRates;
    }

    public boolean[] getUsePayRates() {
      return blnUsePayRates;
    }

    public void recalculateWorkers(int intSpecificJobIndex) {
      double dblWorkRate=((Double)vecSpecificJobsWorkRateApplied.elementAt(intSpecificJobIndex)).doubleValue();
      double dblPayRate=((Double)vecSpecificJobsPayRateApplied.elementAt(intSpecificJobIndex)).doubleValue();

      String strJobName=(String)vecSpecificJobsJobName.elementAt(intSpecificJobIndex);

      Vector vecJobCollection=collection.getJobCollection();

      SpecificJob specificJob=(SpecificJob)vecJobCollection.elementAt(intSpecificJobIndex);

      double dblSpecificJobPayRate=specificJob.getPayRate();

      boolean blnUseWorkerPayRate=specificJob.useWorkerPayRate();

      int intCount=0;

      for(int i=0;i<vecChosenWorkers.size();i++) {
        Worker workerNext=(Worker)vecChosenWorkers.elementAt(i);

        Vector vecJobProficiency=workerNext.getJobProficiencies();

        for(int ia=0;ia<vecJobProficiency.size();ia++) {
          JobProficiency jpNext=(JobProficiency)vecJobProficiency.elementAt(ia);

          Job jobNext=jpNext.getJob();

          if(strJobName.equals(jobNext.getName())) {
            double dblWorkRateNext=jpNext.getRate();

            double dblPayRateNext=jpNext.getPayRate();

            boolean blnAlwaysUseWorkerPayRate=jpNext.alwaysUseWorkerPayRate();

            if(cbSpecificJobsUseJobWork[intSpecificJobIndex].getState()) {
              if(dblWorkRateNext<dblWorkRate) {
                break;
              }
            }

            if(cbSpecificJobsUseJobPay[intSpecificJobIndex].getState()) {
              double dblFinalPayRate=0.0d;

              if(blnAlwaysUseWorkerPayRate) {
                dblFinalPayRate=dblPayRateNext;
              }
              else {
                if(blnUseWorkerPayRate) {
                  dblFinalPayRate=dblPayRateNext;
                }
                else {
                  dblFinalPayRate=dblSpecificJobPayRate;
                }
              }

              if(dblFinalPayRate>dblPayRate) {
                break;
              }
            }

            ++intCount;

/*
            if(dblWorkRateNext>=dblWorkRate) {
              double dblFinalPayRate=0.0d;

              if(blnAlwaysUseWorkerPayRate) {
                dblFinalPayRate=dblPayRateNext;
              }
              else {
                if(blnUseWorkerPayRate) {
                  dblFinalPayRate=dblPayRateNext;
                }
                else {
                  dblFinalPayRate=dblSpecificJobPayRate;
                }
              }

              if(dblFinalPayRate<=dblPayRate) {
                ++intCount;
              }
            }
*/

            break;
          }
        }
      }

      lblSpecificJobsWorkerCount[intSpecificJobIndex].setText(String.valueOf(intCount));
    }

    public void applySpecificJobsCriteria() {
      for(int i=0;i<vecSpecificJobsWorkRateApplied.size();i++) {
        if(checkApplySpecificJobsCriteria(i))
          return;
      }

      for(int i=0;i<vecSpecificJobsWorkRateApplied.size();i++) {
        applySpecificJobsCriteria(i);
      }

      lblStatus.setText("Critera applied");
    }

    public boolean checkApplySpecificJobsCriteria(int i) {
      String strWorkRate=txtSpecificJobsWork[i].getText();
      String strPayRate=txtSpecificJobsPay[i].getText();

      String strSpecificJobName=(String)vecSpecificJobsSpecificJobName.elementAt(i);

      if(strWorkRate.length()==0) {
        lblStatus.setText("Error. Work rate at "+strSpecificJobName+" is required.");

        return true;
      }

      double dblWorkRate=0.0d;

      try {
        dblWorkRate=Double.valueOf(strWorkRate).doubleValue();
      }
      catch(Exception ex) {
        lblStatus.setText("Error. Work rate at "+strSpecificJobName+" must be digits.");

        return true;
      }

      if(dblWorkRate<=0.0d) {
        lblStatus.setText("Error. Work rate at "+strSpecificJobName+" must be positive.");

        return true;
      }


      if(strPayRate.length()==0) {
        lblStatus.setText("Error. Pay rate at "+strSpecificJobName+" is required.");

        return true;
      }

      double dblPayRate=0.0d;

      try {
        dblPayRate=Double.valueOf(strPayRate).doubleValue();
      }
      catch(Exception ex) {
        lblStatus.setText("Error. Pay rate at "+strSpecificJobName+" must be digits.");

        return true;
      }

      if(dblPayRate<=0.0d) {
        lblStatus.setText("Error. Pay rate at "+strSpecificJobName+" must be positive.");

        return true;
      }

      return false;
    }

    public void applySpecificJobsCriteria(int i) {
      String strWorkRate=txtSpecificJobsWork[i].getText();
      String strPayRate=txtSpecificJobsPay[i].getText();

      double dblWorkRate=Double.valueOf(strWorkRate).doubleValue();
      double dblPayRate=Double.valueOf(strPayRate).doubleValue();

      vecSpecificJobsWorkRateApplied.setElementAt(new Double(dblWorkRate), i);
      vecSpecificJobsPayRateApplied.setElementAt(new Double(dblPayRate), i);

      recalculateWorkers(i);
    }

    public void setJobRates(String strWorkRate, String strPayRate, int intJobIndex, String strJobName) {
      double dblWorkRate=Double.valueOf(strWorkRate).doubleValue();
      double dblPayRate=Double.valueOf(strPayRate).doubleValue();

      vecJobWorkRate.setElementAt(new Double(dblWorkRate), intJobIndex);
      vecJobPayRateApplied.setElementAt(new Double(dblPayRate), intJobIndex);

      for(int i=0;i<vecSpecificJobsJobName.size();i++) {
        String strJobNameNext=(String)vecSpecificJobsJobName.elementAt(i);

        if(strJobName.equals(strJobNameNext)) {
            txtSpecificJobsWork[i].setText(strWorkRate);

//          if(cbSpecificJobsUseJobWork[i].getState()) {
//            txtSpecificJobsWork[i].setText(strWorkRate);
//          }

            txtSpecificJobsPay[i].setText(strPayRate);

//          if(cbSpecificJobsUseJobPay[i].getState()) {
//            txtSpecificJobsPay[i].setText(strPayRate);
//          }
        }
      }
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnApplyJobCriteria) {
        int intSelectedIndex=lstJobs.getSelectedIndex();

        if(intSelectedIndex==-1)
          return;

        String strWorkRate=txtWorkRate.getText();

        if(strWorkRate.length()==0) {
          txtWorkRate.setText("Error. Work rate is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtWorkRate.setText("");

          return;
        }

        double dblWorkRate=0.0d;

        try {
          dblWorkRate=Double.valueOf(strWorkRate).doubleValue();
        }
        catch(Exception ex) {
          txtWorkRate.setText("Error. Work rate must be digits.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtWorkRate.setText(strWorkRate);

          return;
        }

        if(dblWorkRate<=0.0d) {
          txtWorkRate.setText("Error. Work rate must be positive.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtWorkRate.setText(strWorkRate);

          return;
        }

        String strPayRate=txtPayRate.getText();

        if(strPayRate.length()==0) {
          txtPayRate.setText("Error. Pay rate is required.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtPayRate.setText("");

          return;
        }

        double dblPayRate=0.0d;

        try {
          dblPayRate=Double.valueOf(strPayRate).doubleValue();
        }
        catch(Exception ex) {
          txtPayRate.setText("Error. Pay rate must be digits.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtPayRate.setText(strPayRate);

          return;
        }

        if(dblPayRate<=0.0d) {
          txtPayRate.setText("Error. Pay rate must be positive.");

          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex2) {
          }

          txtPayRate.setText(strPayRate);

          return;
        }

        setJobRates(strWorkRate, strPayRate, intSelectedIndex, lstJobs.getItem(intSelectedIndex));

        applySpecificJobsCriteria();
      }
      else if(evSource==btnRestoreDefaultCriteria) {
        for(int i=0;i<vecJobWorkRate.size();i++) {
//          vecJobWorkRate.setElementAt(new Double(1.0d), i);
//          vecJobPayRateApplied.setElementAt(vecJobPayRate.elementAt(i), i);

          setJobRates("1.0", String.valueOf(((Double)vecJobPayRate.elementAt(i)).doubleValue()), i, lstJobs.getItem(i));
        }

        txtWorkRate.setText("");
        txtPayRate.setText("");

//        txtWorkRate.setText("1.0");
//        txtPayRate.setText(String.valueOf(((Double)vecJobPayRate.elementAt(i)).doubleValue()));

        applySpecificJobsCriteria();
      }
      else if(evSource==btnProcess) {
        blnUseCriteria=new boolean[cbSpecificJobsUseCriteria.length];

        for(int i=0;i<blnUseCriteria.length;i++) {
          blnUseCriteria[i]=cbSpecificJobsUseCriteria[i].getState();
//System.out.println("use criteria: "+i+":"+blnUseCriteria[i]);
        }

        dblWorkRates=new double[vecSpecificJobsWorkRateApplied.size()];

        for(int i=0;i<dblWorkRates.length;i++)
          dblWorkRates[i]=((Double)vecSpecificJobsWorkRateApplied.elementAt(i)).doubleValue();

        dblPayRates=new double[vecSpecificJobsPayRateApplied.size()];

        for(int i=0;i<dblPayRates.length;i++)
          dblPayRates[i]=((Double)vecSpecificJobsPayRateApplied.elementAt(i)).doubleValue();

        blnUseWorkRates=new boolean[cbSpecificJobsUseJobWork.length];

        for(int i=0;i<blnUseWorkRates.length;i++) {
          blnUseWorkRates[i]=cbSpecificJobsUseJobWork[i].getState();
//System.out.println("use criteria work rate: "+i+":"+blnUseWorkRates[i]);
        }

        blnUsePayRates=new boolean[cbSpecificJobsUseJobPay.length];

        for(int i=0;i<blnUsePayRates.length;i++) {
          blnUsePayRates[i]=cbSpecificJobsUseJobPay[i].getState();
//System.out.println("use criteria pay rate: "+i+":"+blnUsePayRates[i]);
        }

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
      else {
        for(int i=0;i<btnSpecificJobsApply.length;i++) {
          if(evSource==btnSpecificJobsApply[i]) {
            if(checkApplySpecificJobsCriteria(i))
              break;

            applySpecificJobsCriteria(i);

            recalculateWorkers(i);

            break;
          }
          else if(evSource==btnSpecificJobsSetJobWork[i]) {
            String strJobName=(String)vecSpecificJobsJobName.elementAt(i);

            for(int ia=0;ia<lstJobs.getItemCount();ia++) {
              if(strJobName.equals(lstJobs.getItem(ia))) {
                double dblWorkRate=((Double)vecJobWorkRate.elementAt(ia)).doubleValue();

                txtSpecificJobsWork[i].setText(String.valueOf(dblWorkRate));

                vecSpecificJobsWorkRateApplied.setElementAt(new Double(dblWorkRate), i);

                recalculateWorkers(i);

                break;
              }
            }
          }
          else if(evSource==btnSpecificJobsSetJobPay[i]) {
            String strJobName=(String)vecSpecificJobsJobName.elementAt(i);

            for(int ia=0;ia<lstJobs.getItemCount();ia++) {
              if(strJobName.equals(lstJobs.getItem(ia))) {
                double dblPayRate=((Double)vecJobPayRateApplied.elementAt(ia)).doubleValue();

                txtSpecificJobsPay[i].setText(String.valueOf(dblPayRate));

                vecSpecificJobsPayRateApplied.setElementAt(new Double(dblPayRate), i);

                recalculateWorkers(i);

                break;
              }
            }
          }
        }
      }
    }

    public void itemStateChanged(ItemEvent ie) {
      Object evSource=ie.getSource();

      if(evSource==lstJobs) {
        int intSelectedIndex=lstJobs.getSelectedIndex();

        if(intSelectedIndex==-1)
          return;

        txtWorkRate.setText(String.valueOf(((Double)vecJobWorkRate.elementAt(intSelectedIndex)).doubleValue()));
        txtPayRate.setText(String.valueOf(((Double)vecJobPayRateApplied.elementAt(intSelectedIndex)).doubleValue()));
      }
      else {
        for(int i=0;i<cbSpecificJobsUseJobWork.length;i++) {
          if(evSource==cbSpecificJobsUseJobWork[i]) {
            if(cbSpecificJobsUseJobWork[i].getState()) {
              if(checkApplySpecificJobsCriteria(i))
                break;

              applySpecificJobsCriteria(i);

              recalculateWorkers(i);

              break;
            }
            else {
              applySpecificJobsCriteria(i);

              recalculateWorkers(i);

              break;
            }
          }
        }

        for(int i=0;i<cbSpecificJobsUseJobPay.length;i++) {
          if(evSource==cbSpecificJobsUseJobPay[i]) {
            if(cbSpecificJobsUseJobPay[i].getState()) {
              if(checkApplySpecificJobsCriteria(i))
                break;

              applySpecificJobsCriteria(i);

              recalculateWorkers(i);

              break;
            }
            else {
              applySpecificJobsCriteria(i);

              recalculateWorkers(i);

              break;
            }
          }
        }


/*
        for(int i=0;i<cbSpecificJobsUseJobWork.length;i++) {
          if(evSource==cbSpecificJobsUseJobWork[i]) {
            if(cbSpecificJobsUseJobWork[i].getState()) {
              String strJobName=(String)vecSpecificJobsJobName.elementAt(i);

              for(int ia=0;ia<lstJobs.getItemCount();ia++) {
                if(strJobName.equals(lstJobs.getItem(ia))) {
                  double dblWorkRate=((Double)vecJobWorkRate.elementAt(ia)).doubleValue();

                  txtSpecificJobsWork[i].setText(String.valueOf(dblWorkRate));

                  vecSpecificJobsWorkRateApplied.setElementAt(new Double(dblWorkRate), i);

                  recalculateWorkers(i);

                  break;
                }
              }
            }

            break;
          }
        }

        for(int i=0;i<cbSpecificJobsUseJobPay.length;i++) {
          if(evSource==cbSpecificJobsUseJobPay[i]) {
            if(cbSpecificJobsUseJobPay[i].getState()) {
              String strJobName=(String)vecSpecificJobsJobName.elementAt(i);

              for(int ia=0;ia<lstJobs.getItemCount();ia++) {
                if(strJobName.equals(lstJobs.getItem(ia))) {
                  double dblPayRate=((Double)vecJobPayRateApplied.elementAt(ia)).doubleValue();

                  txtSpecificJobsPay[i].setText(String.valueOf(dblPayRate));

                  vecSpecificJobsPayRateApplied.setElementAt(new Double(dblPayRate), i);

                  recalculateWorkers(i);

                  break;
                }
              }
            }

            break;
          }
        }
*/
      }
    }
  }
}