package bim.workEfficiencyPlanner;

import java.io.Serializable;

public class JobProficiency
implements Serializable, Cloneable {
  volatile Double dblRate=new Double(0.0d);  //A factor compared to the average worker 1.0=average, 0.5=halfTheOfAverage, 2.0=doubleThatOfAverage, etc

  volatile Double dblPayRate=new Double(0.0d); //A value of 0.0 means no pay rate preferred

  volatile Boolean blnAlwaysUseWorkerPayRate=new Boolean(true);

  volatile Job job=null;

  public JobProficiency() {
  }

  public JobProficiency(double dblRate0, double dblPayRate0, boolean blnAlwaysUseWorkerPayRate0, Job job) {
    this.dblRate=new Double(dblRate0);
    this.dblPayRate=new Double(dblPayRate0);
    this.blnAlwaysUseWorkerPayRate=new Boolean(blnAlwaysUseWorkerPayRate0);
    this.job=job;
  }

  public double getRate() {
    return dblRate.doubleValue();
  }

  public void setRate(double dblRate0) {
    this.dblRate=new Double(dblRate0);
  }

  public double getPayRate() {
    return dblPayRate.doubleValue();
  }

  public void setPayRate(double dblPayRate0) {
    this.dblPayRate=new Double(dblPayRate0);
  }

  public boolean alwaysUseWorkerPayRate() {
    return blnAlwaysUseWorkerPayRate.booleanValue();
  }

  public void setAlwaysUseWorkerPayRate(boolean blnAlwaysUseWorkerPayRate0) {
    this.blnAlwaysUseWorkerPayRate=new Boolean(blnAlwaysUseWorkerPayRate0);
  }

  public Job getJob() {
    return job;
  }

  public void setJob(Job job) {
    this.job=job;
  }

  public Object clone() {
    JobProficiency jpClone=new JobProficiency(dblRate.doubleValue(), dblPayRate.doubleValue(), blnAlwaysUseWorkerPayRate.booleanValue(), (Job)job.clone());

    return jpClone;
  }
}