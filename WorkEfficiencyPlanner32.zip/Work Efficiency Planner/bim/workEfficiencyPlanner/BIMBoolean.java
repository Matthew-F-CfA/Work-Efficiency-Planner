package bim.workEfficiencyPlanner;

class BIMBoolean {
  volatile boolean blnBln=true;

  BIMBoolean(boolean blnBln) {
    this.blnBln=blnBln;
  }

  public boolean getBln() {
    return blnBln;
  }

  public void setBln(boolean blnBln) {
    this.blnBln=blnBln;
  }
}