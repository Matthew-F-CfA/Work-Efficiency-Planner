package bim.workEfficiencyPlanner;

import java.awt.*;
import java.util.Vector;

class BIMTextAreaThread extends TextArea
implements Runnable {
  volatile Object objSync=new Object();

  volatile Vector vecContents=new Vector();

  volatile boolean blnKeepAlive=true;


  BIMTextAreaThread() {
    super();
  }

  BIMTextAreaThread(int intRows, int intColumns) {
    super(intRows, intColumns);
  }

  public void setText(String strText) {
synchronized(objSync) {
    vecContents.removeAllElements();

    super.setText(strText);
}
  }

  public void append(String strText) {
synchronized(objSync) {
    vecContents.addElement(strText);
}
  }

  public void run() {
    try {
      while(blnKeepAlive) {
        Thread.sleep(2000l);

synchronized(objSync) {
        StringBuffer sbuf=new StringBuffer();

        int intCount=vecContents.size();
        for(int i=0;i<intCount;i++) {
          String strNext=(String)vecContents.elementAt(0);
          vecContents.removeElementAt(0);

          sbuf.append(strNext);
        }

        super.append(sbuf.toString());
}
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}