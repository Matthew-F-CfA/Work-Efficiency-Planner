package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;

class BIMMessageDialog extends Dialog
implements ActionListener {
  volatile Button btnOkay=new Button("Okay");

  BIMMessageDialog(Frame parent, String strTitle, String strMessage) {
    super(parent, strTitle, true);

    setLayout(new BorderLayout());

    add("Center", new Label(strMessage));

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnOkay);
    btnOkay.addActionListener(this);

    add("South", pnlTemp);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    setLocation(dimScreen.width/4, dimScreen.height/4);
    setSize(dimScreen.width/2, dimScreen.height/2);
  }

  BIMMessageDialog(Frame parent, String strTitle, String strMessage[]) {
    super(parent, strTitle, true);

    setLayout(new BorderLayout());

    TextArea txtTemp=new TextArea();
    for(int i=0;i<strMessage.length;i++)
      txtTemp.append(strMessage[i]+"\n");

    add("Center", txtTemp);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnOkay);
    btnOkay.addActionListener(this);

    add("South", pnlTemp);

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    setLocation(dimScreen.width/4, dimScreen.height/4);
    setSize(dimScreen.width/2, dimScreen.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnOkay)
      dispose();
  }
}