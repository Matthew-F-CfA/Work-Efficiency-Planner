package bim.workEfficiencyPlanner;

import java.util.Vector;
import java.io.Serializable;
import java.io.IOException;
import java.io.ObjectInputStream;

public class SpecificJob
implements Serializable, Cloneable, Comparable {
  volatile String strName="";
  volatile String strDescription="";

  volatile Double dblHalfHours=new Double(0.0d);

  volatile Double dblPayRate=new Double(0.0d);  //Money paid for each half hour completed for each worker

  volatile Boolean blnUseWorkerPayRate=new Boolean(true);

  volatile Job job=null;

  volatile Integer intMaxWorkers=new Integer(0);

  volatile Vector vecDependentOn=new Vector();

  volatile transient Vector vecWorkSchedule=new Vector(); //elements of SpecificJobWorked
  volatile transient Double dblHalfHoursCompleted=new Double(0.0d);
  volatile transient Integer intRelativeJobStartTime=new Integer(0);

  public SpecificJob() {
  }

  public SpecificJob(String strName, String strDescription, double dblHalfHours0, double dblPayRate0, Job job, int intMaxWorkers0) {
    this.strName=strName;
    this.strDescription=strDescription;
    this.dblHalfHours=new Double(dblHalfHours0);
    this.dblPayRate=new Double(dblPayRate0);
    this.job=job;
    this.intMaxWorkers=new Integer(intMaxWorkers0);
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) { 
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public double getHalfHours() {
    return dblHalfHours.doubleValue();
  }

  public void setHalfHours(double dblHalfHours0) {
    this.dblHalfHours=new Double(dblHalfHours0);
  }

  public double getPayRate() {
    return dblPayRate.doubleValue();
  }

  public void setPayRate(double dblPayRate0) {
    this.dblPayRate=new Double(dblPayRate0);
  }

  public boolean useWorkerPayRate() {
    return blnUseWorkerPayRate.booleanValue();
  }

  public void setUseWorkerPayRate(boolean blnUseWorkerPayRate0) {
    this.blnUseWorkerPayRate=new Boolean(blnUseWorkerPayRate0);
  }

  public Job getJob() {
    return job;
  }

  public void setJob(Job job) {
    this.job=job;
  }

  public int getMaxWorkers() {
    return intMaxWorkers.intValue();
  }

  public void setMaxWorkers(int intMaxWorkers0) {
    this.intMaxWorkers=new Integer(intMaxWorkers0);
  }

  public Vector getDependentOn() {
    return vecDependentOn;
  }

  public void setDependentOn(Vector vecDependentOn) {
    this.vecDependentOn=vecDependentOn;
  }

  public void addDependentOn(SpecificJob specificJob) {
    if(specificJob.getName().equals(getName()))
      return;

    int i=0;

    for(;i<vecDependentOn.size();i++) {
      SpecificJob specificJobNext=(SpecificJob)vecDependentOn.elementAt(i);

      if(specificJob.getName().equals(specificJobNext.getName())) {
        break;
      }
    }

    if(i==vecDependentOn.size()) {
      vecDependentOn.addElement(specificJob);
    }
  }

  public void removeDependentOn(SpecificJob specificJob) {
    for(int i=0;i<vecDependentOn.size();i++) {
      SpecificJob specificJobNext=(SpecificJob)vecDependentOn.elementAt(i);

      if(specificJob.getName().equals(specificJobNext.getName())) {
        vecDependentOn.removeElementAt(i);
        --i;
      }
    }
  }

  public Vector getWorkSchedule() {
    return vecWorkSchedule;
  }

  public void setWorkSchedule(Vector vecWorkSchedule) {
    this.vecWorkSchedule=vecWorkSchedule;
  }

  public double getHalfHoursCompleted() {
    return dblHalfHoursCompleted.doubleValue();
  }

  public void setHalfHoursCompleted(double dblHalfHoursCompleted0) {
    this.dblHalfHoursCompleted=new Double(dblHalfHoursCompleted0);
  }

  public int getRelativeJobStartTime() {
    return intRelativeJobStartTime.intValue();
  }

  public void setRelativeJobStartTime(int intRelativeJobStartTime0) {
    this.intRelativeJobStartTime=new Integer(intRelativeJobStartTime0);
  }

  private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
    ois.defaultReadObject();

    vecWorkSchedule=new Vector();
    dblHalfHoursCompleted=new Double(0.0d);
    intRelativeJobStartTime=new Integer(0);
  }

  public void copyDependents(Vector vecJobCollection) {
    for(int ia=0;ia<vecDependentOn.size();ia++) {
      SpecificJob sjdNext=(SpecificJob)vecDependentOn.elementAt(ia);

      for(int iz=0;iz<vecJobCollection.size();iz++) {
        SpecificJob sjNext2=(SpecificJob)vecJobCollection.elementAt(iz);

        if(sjdNext.getName().equals(sjNext2.getName())) {
          vecDependentOn.setElementAt(sjNext2, ia);

          break;
        }
      }
    }
  }

  public Object clone() {
    SpecificJob sjClone=new SpecificJob(strName.toString(), strDescription.toString(), dblHalfHours.doubleValue(), dblPayRate.doubleValue(), (Job)job.clone(), intMaxWorkers.intValue());
    sjClone.setUseWorkerPayRate(useWorkerPayRate());
    sjClone.setHalfHoursCompleted(dblHalfHoursCompleted.doubleValue());
    sjClone.setRelativeJobStartTime(getRelativeJobStartTime());

    Vector vecDOClone=new Vector();
    for(int i=0;i<vecDependentOn.size();i++) {
      SpecificJob sjNext=(SpecificJob)vecDependentOn.elementAt(i);

      vecDOClone.addElement(sjNext.clone());
    }
    sjClone.setDependentOn(vecDOClone);

    Vector vecWSClone=new Vector();
    for(int i=0;i<vecWorkSchedule.size();i++) {
      SpecificJobWorked sjwNext=(SpecificJobWorked)vecWorkSchedule.elementAt(i);

      vecWSClone.addElement(sjwNext.clone());
    }
    sjClone.setWorkSchedule(vecWSClone);

    return sjClone;
  }

  public int compareTo(Object obj) {
    SpecificJob objSJ=(SpecificJob)obj;

    return strName.compareTo(objSJ.getName());
  }

  public String toString() {
    StringBuffer sbuf=new StringBuffer();

    sbuf.append("Name: ");
    sbuf.append(strName);
    sbuf.append("\nHalf Hours: ");
    sbuf.append(dblHalfHours.doubleValue());
    sbuf.append("\nPay Rate: $");
    sbuf.append(dblPayRate.doubleValue());
    sbuf.append("\nUse Worker Pay Rate: ");
    sbuf.append(blnUseWorkerPayRate.booleanValue());
    sbuf.append("\nJob Proficiency: ");
    sbuf.append(job.getName());
    sbuf.append("\nMax Workers: ");
    sbuf.append(intMaxWorkers.intValue());
    sbuf.append("\n\nDescription:\n");
    sbuf.append(strDescription);

    return sbuf.toString();
  }
}