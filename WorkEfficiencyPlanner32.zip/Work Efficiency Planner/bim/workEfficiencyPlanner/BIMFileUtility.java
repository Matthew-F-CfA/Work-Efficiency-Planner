package bim.workEfficiencyPlanner;

import java.io.*;
import java.util.Vector;

class BIMFileUtility {

  public static File[] copyFiles(File files[]) throws Exception {
    File fileReturn[]=new File[files.length];

    for(int i=0;i<files.length;i++)
      fileReturn[i]=copyFileTemp(files[i]);

    return fileReturn;
  }

  public static File copyFileTemp(File file) throws Exception {
    File fileReturn=File.createTempFile("bimTemp", "batch");

    return copyFile(file, fileReturn);
  }

  public static File copyFile(File file, File fileReturn) throws Exception {
    BufferedInputStream bis=new BufferedInputStream(new FileInputStream(file));

    BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(fileReturn));

    int intAvail=-1;
    byte bbuf[]=new byte[100000];

    while(true) {
      intAvail=bis.available();

      if(intAvail<1) {
        int intByte=bis.read();

        if(intByte==-1)
          break;

        bos.write(intByte);

        continue;
      }
      else {
        intAvail=bbuf.length;
      }
      
      bis.read(bbuf, 0, intAvail);
      bos.write(bbuf, 0, intAvail);

      bos.flush();
    }

    bis.close();
    bos.close();

    return fileReturn;
  }

  public static void restoreFiles(File files[], File fileNames[]) throws Exception {
    for(int i=0;i<files.length;i++) {
      copyFile(files[i], fileNames[i]);
    }
  }

  public static File[] narrowFiles(File files[], String strExtension) throws Exception {
    Vector vecFiles=new Vector();

    for(int i=0;i<files.length;i++) {
      if(files[i].getName().endsWith(strExtension))
        vecFiles.addElement(files[i]);
    }

    File filesReturn[]=new File[vecFiles.size()];

    for(int i=0;i<vecFiles.size();i++)
      filesReturn[i]=(File)vecFiles.elementAt(i);

    return filesReturn;
  }
}