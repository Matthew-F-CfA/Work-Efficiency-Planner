package bim.workEfficiencyPlanner;

import java.io.Serializable;
import java.util.Vector;
import java.util.Arrays;

class BIMSetSorter {

  public static Vector sortVector(Vector vecVec, String strElementsType) {
    Vector vecReturn=new Vector();

    if(strElementsType.equals("Worker")) {
      Worker workerArr[]=new Worker[vecVec.size()];

      for(int i=0;i<workerArr.length;i++)
        workerArr[i]=(Worker)vecVec.elementAt(i);

      Arrays.sort(workerArr);

      for(int i=0;i<workerArr.length;i++)
        vecReturn.addElement(workerArr[i]);
    }
    else if(strElementsType.equals("Job")) {
      Job jobArr[]=new Job[vecVec.size()];

      for(int i=0;i<jobArr.length;i++)
        jobArr[i]=(Job)vecVec.elementAt(i);

      Arrays.sort(jobArr);

      for(int i=0;i<jobArr.length;i++)
        vecReturn.addElement(jobArr[i]);
    }
    else if(strElementsType.equals("SpecificJob")) {
      SpecificJob jobArr[]=new SpecificJob[vecVec.size()];

      for(int i=0;i<jobArr.length;i++)
        jobArr[i]=(SpecificJob)vecVec.elementAt(i);

      Arrays.sort(jobArr);

      for(int i=0;i<jobArr.length;i++)
        vecReturn.addElement(jobArr[i]);
    }

    return vecReturn;
  }
}