package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class MainFrameJob extends Frame
implements ActionListener, ItemListener {
  List lstJobs=new List(5);
  Button btnRemoveJob=new Button("Remove Job");  //Do not include this because of dependencies with workers

  TextField txtJobName=new TextField();
  TextField txtPayRate=new TextField();
  TextArea txtJobDescription=new TextArea(5, 100);
  Button btnAddSetJob=new Button("Add Job / Set Pay Rate and Job Description");

  Vector vecJobs=new Vector();
  

  public static void main(String args[]) {
    MainFrameJob mFrame=new MainFrameJob();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    try {
      File fileJobs=new File("Jobs");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileJobs));
      Vector vecJobs=(Vector)ois.readObject();
      ois.close();

      mFrame.vecJobs=vecJobs;
      for(int i=0;i<vecJobs.size();i++) {
        Job jobNext=(Job)vecJobs.elementAt(i);

        mFrame.lstJobs.add(jobNext.getName());
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  MainFrameJob() {
    super("Jobs");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("North", new Label("Jobs:"));
    add("Center", lstJobs);
    lstJobs.addItemListener(this);

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new BorderLayout());
    Panel pnlTempA=new Panel();
    pnlTempA.setLayout(new GridLayout(2, 2));
    pnlTempA.add(new Label("Job Name:"));
    pnlTempA.add(txtJobName);
    pnlTempA.add(new Label("Pay Rate:"));
    pnlTempA.add(txtPayRate);
    pnlTemp.add("North", pnlTempA);
    pnlTemp.add("Center", txtJobDescription);
    Panel pnlTempB=new Panel();
    pnlTempB.add(btnAddSetJob);
    btnAddSetJob.addActionListener(this);
    pnlTemp.add("South", pnlTempB);
    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnAddSetJob) {
      String strName=txtJobName.getText();

      if(strName.length()==0) {
        txtJobName.setText("Error. Job name is required.");

        try {
          Thread.sleep(3000l);
        }
        catch(Exception ex) {
        }

        txtJobName.setText("");

        return;
      }

      String strPayRate=txtPayRate.getText();

      if(strPayRate.length()==0) {
        txtPayRate.setText("Error. Pay rate is required.");

        try {
          Thread.sleep(3000l);
        }
        catch(Exception ex) {
        }

        txtPayRate.setText("");

        return;
      }

      double dblPayRate=0.0d;

      try {
        dblPayRate=Double.valueOf(strPayRate).doubleValue();
      }
      catch(Exception ex) {
        txtPayRate.setText("Error. Pay rate must be digits.");

        try {
          Thread.sleep(3000l);
        }
        catch(Exception ex2) {
        }

        txtPayRate.setText(strPayRate);

        return;
      }

      if(dblPayRate<=0.0d) {
        txtPayRate.setText("Error. Pay rate must be a positive number.");

        try {
          Thread.sleep(3000l);
        }
        catch(Exception ex) {
        }

        txtPayRate.setText(strPayRate);

        return;
      }

      String strDescription=txtJobDescription.getText();

      int i=0;

      for(;i<vecJobs.size();i++) {
        Job jobNext=(Job)vecJobs.elementAt(i);

        if(strName.equals(jobNext.getName())) {
          jobNext.setPayRate(dblPayRate);
          jobNext.setDescription(strDescription);

          break;
        }
      }

      if(i==vecJobs.size()) {
        Job jobNew=new Job(strName, strDescription, dblPayRate);

        vecJobs.addElement(jobNew);

        vecJobs=BIMSetSorter.sortVector(vecJobs, "Job");

        lstJobs.removeAll();
        for(int ia=0;ia<vecJobs.size();ia++)
          lstJobs.add(((Job)vecJobs.elementAt(ia)).getName());
      }

      try {
        File fileJobs=new File("Jobs");
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileJobs));
        oos.writeObject(vecJobs);
        oos.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }

  public void itemStateChanged(ItemEvent ie) {
    Object evSource=ie.getSource();

    if(evSource==lstJobs) {
      int intSelectedIndex=lstJobs.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      Job job=(Job)vecJobs.elementAt(intSelectedIndex);

      txtJobName.setText(job.getName());
      txtPayRate.setText(String.valueOf(job.getPayRate()));
      txtJobDescription.setText(job.getDescription());
    }
  }
}