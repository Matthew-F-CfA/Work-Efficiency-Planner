package bim.workEfficiencyPlanner;

import java.util.Vector;
import java.io.Serializable;

public class Worker
implements Serializable, Cloneable, Comparable {
  volatile String strName="";
  volatile String strDescription="";

  volatile Vector vecJobProficiency=new Vector();  //Elements of JobProficiency  
  volatile Vector vecRestrictedCoworkers=new Vector();  //Elements of Worker


  public Worker() {
  }

  public Worker(String strName, String strDescription) {
    this.strName=strName;
    this.strDescription=strDescription;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public String getDescription() {
    return strDescription;
  }

  public void setDescription(String strDescription) {
    this.strDescription=strDescription;
  }

  public Vector getJobProficiencies() {
    return vecJobProficiency;
  }

  public void setJobProficiencies(Vector vecJobProficiency) {
    this.vecJobProficiency=vecJobProficiency;
  }

  public boolean hasJobProficiency(Job job) {
    for(int i=0;i<vecJobProficiency.size();i++) {
      JobProficiency jobNext=(JobProficiency)vecJobProficiency.elementAt(i);

      if(job.getName().equals(jobNext.getJob().getName()))
        return true;
    }

    return false;
  }

  public Vector getRestrictedCoworkers() {
    return vecRestrictedCoworkers;
  }

  public void setRestrictedCoworkers(Vector vecRestrictedCoworkers) {
    this.vecRestrictedCoworkers=vecRestrictedCoworkers;
  }

  public boolean hasRestrictedCoworker(Worker worker) {
    for(int i=0;i<vecRestrictedCoworkers.size();i++) {
      Worker workerNext=(Worker)vecRestrictedCoworkers.elementAt(i);

      if(worker.getName().equals(workerNext.getName()))
        return true;
    }

    return false;
  }

  public Object clone() {
    Worker wClone=new Worker(strName.toString(), strDescription.toString());

    Vector vecJPClone=new Vector();
    for(int i=0;i<vecJobProficiency.size();i++) {
      JobProficiency jpNext=(JobProficiency)vecJobProficiency.elementAt(i);

      vecJPClone.addElement(jpNext.clone());
    }
    wClone.setJobProficiencies(vecJPClone);

    Vector vecRCClone=new Vector();
    for(int i=0;i<vecRestrictedCoworkers.size();i++) {
      Worker wNext=(Worker)vecRestrictedCoworkers.elementAt(i);

      vecRCClone.addElement(wNext.clone0());
    }
    wClone.setRestrictedCoworkers(vecRCClone);

    return wClone;
  }

  public Object clone0() {
    Worker wClone=new Worker(strName.toString(), strDescription.toString());

    Vector vecJPClone=new Vector();
    for(int i=0;i<vecJobProficiency.size();i++) {
      JobProficiency jpNext=(JobProficiency)vecJobProficiency.elementAt(i);

      vecJPClone.addElement(jpNext.clone());
    }
    wClone.setJobProficiencies(vecJPClone);

/*
    Vector vecRCClone=new Vector();
    for(int i=0;i<vecRestrictedCoworkers.size();i++) {
      Worker wNext=(Worker)vecRestrictedCoworkers.elementAt(i);

      vecRCClone.addElement(wNext.clone0());
    }
    wClone.setRestrictedCoworkers(vecRCClone);
*/

    return wClone;
  }

  public int compareTo(Object obj) {
    Worker workerObj=(Worker)obj;

    return strName.compareTo(workerObj.getName());
  }
}