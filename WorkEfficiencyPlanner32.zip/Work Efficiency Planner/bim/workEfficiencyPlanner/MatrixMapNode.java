package bim.workEfficiencyPlanner;

class MatrixMapNode {
  static int DO_INCLUDE=0;
  static int DONT_INCLUDE=1;

  static int DO_IGNORE=0;
  static int DONT_IGNORE=1;

  volatile int intInclusion=0;
  volatile int intIgnore=0;

  MatrixMapNode(int intInclusion, int intIgnore) {
    this.intInclusion=intInclusion;
    this.intIgnore=intIgnore;
  }

  public boolean doInclude() {
    if(intInclusion==DO_INCLUDE)
      return true;

    return false;
  }

  public boolean doIgnore() {
    if(intIgnore==DO_IGNORE)
      return true;

    return false;
  }
}