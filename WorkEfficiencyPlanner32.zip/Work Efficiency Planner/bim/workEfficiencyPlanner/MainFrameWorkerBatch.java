package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class MainFrameWorkerBatch extends Frame
implements ActionListener {
  List lstWorkers=new List(10);
  Button btnAddWorker=new Button("Add Worker");
  List lstWorkerBatch=new List(10);
  Button btnRemoveWorker=new Button("Remove Worker");

  Button btnSaveWorkerBatch=new Button("Save Worker Batch");
  Button btnLoadWorkerBatch=new Button("Load Worker Batch");

  Vector vecWorkers=new Vector();

  Vector vecWorkerBatch=new Vector();

  public static void main(String args[]) {
    MainFrameWorkerBatch mFrame=new MainFrameWorkerBatch();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    try {
      File fileWorkers=new File("Workers");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileWorkers));
      mFrame.vecWorkers=(Vector)ois.readObject();
      ois.close();

      for(int i=0;i<mFrame.vecWorkers.size();i++) {
        Worker workerNext=(Worker)mFrame.vecWorkers.elementAt(i);

        mFrame.lstWorkers.add(workerNext.getName());
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  MainFrameWorkerBatch() {
    super("Worker Batch");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new GridLayout(2, 1));
    Panel pnlTempA=new Panel();
    pnlTempA.setLayout(new BorderLayout());
    pnlTempA.add("North", new Label("All Workers:"));
    pnlTempA.add("Center", lstWorkers);
    Panel pnlTempA1=new Panel();
    pnlTempA1.add(btnAddWorker);
    btnAddWorker.addActionListener(this);
    pnlTempA.add("South", pnlTempA1);
    pnlTemp.add(pnlTempA);
    Panel pnlTempB=new Panel();
    pnlTempB.setLayout(new BorderLayout());
    pnlTempB.add("North", new Label("Batch Workers:"));
    pnlTempB.add("Center", lstWorkerBatch);
    Panel pnlTempB1=new Panel();
    pnlTempB1.add(btnRemoveWorker);
    btnRemoveWorker.addActionListener(this);
    pnlTempB.add("South", pnlTempB1);
    pnlTemp.add(pnlTempB);

    add("Center", pnlTemp);

    Panel pnlTemp2=new Panel();
    pnlTemp2.add(btnSaveWorkerBatch);
    btnSaveWorkerBatch.addActionListener(this);
    pnlTemp2.add(btnLoadWorkerBatch);
    btnLoadWorkerBatch.addActionListener(this);

    add("South", pnlTemp2);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnAddWorker) {
      int intSelectedIndex=lstWorkers.getSelectedIndex();

      if(intSelectedIndex==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Add Worker", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      Worker worker=(Worker)vecWorkers.elementAt(intSelectedIndex);

      for(int i=0;i<vecWorkerBatch.size();i++) {
        Worker workerNext=(Worker)vecWorkerBatch.elementAt(i);

        if(worker.getName().equals(workerNext.getName()))
          return;
      }

      vecWorkerBatch.addElement(worker);

      lstWorkerBatch.add(worker.getName());
    }
    else if(evSource==btnRemoveWorker) {
      int intSelectedIndex=lstWorkerBatch.getSelectedIndex();

      if(intSelectedIndex==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Worker", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      vecWorkerBatch.removeElementAt(intSelectedIndex);

      lstWorkerBatch.remove(intSelectedIndex);
    }
    else if(evSource==btnSaveWorkerBatch) {
      BIMSaveDialog sDialog=new BIMSaveDialog(this, ".batch");
      sDialog.show();

      if(sDialog.cancelIt)
        return;

      String strSaveName=sDialog.getSaveName()+".batch";

      try {
        File fileSave=new File(strSaveName);
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileSave));
        oos.writeObject(vecWorkerBatch);
        oos.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==btnLoadWorkerBatch) {
      BIMLoadDialog lDialog=new BIMLoadDialog(this, ".batch");
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      String strLoadName=lDialog.getLoadName()+".batch";

      try {
        File fileLoad=new File(strLoadName);
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileLoad));
        vecWorkerBatch=(Vector)ois.readObject();
        ois.close();

        lstWorkerBatch.removeAll();
        for(int i=0;i<vecWorkerBatch.size();i++) {
          Worker workerNext=(Worker)vecWorkerBatch.elementAt(i);

          lstWorkerBatch.add(workerNext.getName());
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }
}