package bim.workEfficiencyPlanner;

class SpecificJobArrangement
implements Cloneable {
  volatile String strWorkerName="";
  volatile String strSpecificJob="";

  SpecificJobArrangement(String strWorkerName, String strSpecificJob) {
    this.strWorkerName=strWorkerName;
    this.strSpecificJob=strSpecificJob;
  }

  public String getWorkerName() {
    return strWorkerName;
  }

  public String getSpecificJob() {
    return strSpecificJob;
  }

  public Object clone() {
    SpecificJobArrangement sjaClone=new SpecificJobArrangement(getWorkerName().toString(), getSpecificJob().toString());

    return sjaClone;
  }
}