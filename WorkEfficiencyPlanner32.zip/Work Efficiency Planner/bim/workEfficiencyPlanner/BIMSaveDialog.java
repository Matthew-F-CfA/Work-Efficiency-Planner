package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

  class BIMSaveDialog extends Dialog
  implements ActionListener {
    volatile TextField txtSaveName=new TextField();

    volatile Button btnSave=new Button("Save");
    volatile Button btnCancel=new Button("Cancel");

    volatile boolean cancelIt=false;

    volatile String strSaveName="";

    volatile String strExtension="";

    BIMSaveDialog(Frame parent, String strExtension) {
      super(parent, "Save Dialog", true);

      this.strExtension=strExtension;

      setLayout(new BorderLayout());

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(1, 2));
      pnlTemp.add(new Label("Save Name:"));
      pnlTemp.add(txtSaveName);
      add("North", pnlTemp);

      add("Center", new Label(""));

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnSave);
      btnSave.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/3, dimScreen.height/3);
      setSize(dimScreen.width/3, dimScreen.height/3);
    }

    public String getSaveName() {
      return strSaveName;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSave) {
        strSaveName=txtSaveName.getText();

        if(strSaveName.indexOf(".")!=-1) {
          txtSaveName.setText("\".\" is an illegal character.");
          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtSaveName.setText(strSaveName);

          return;
        }

        String strStr=strSaveName+strExtension;

        if(new File(strStr).exists()) {
          txtSaveName.setText("File exists. Use another name.");
          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtSaveName.setText(strSaveName);

          return;
        }

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) { 
        cancelIt=true;

        dispose();
      }
    }
  }
