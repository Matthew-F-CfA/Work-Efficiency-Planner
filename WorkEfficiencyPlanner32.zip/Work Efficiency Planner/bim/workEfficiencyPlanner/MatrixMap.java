package bim.workEfficiencyPlanner;

import java.util.Vector;

class MatrixMap {
  volatile Vector vecMapArray=new Vector();

  volatile Vector vecWorkers=new Vector();
  volatile Vector vecJobCollection=new Vector();
  volatile Vector vecAvailableWorkersJobs=new Vector();


  MatrixMap(Vector vecWorkers, Vector vecJobCollection, Vector vecAvailableWorkersJobs) {
    this.vecWorkers=vecWorkers;
    this.vecJobCollection=vecJobCollection;
    this.vecAvailableWorkersJobs=vecAvailableWorkersJobs;

    buildMapArray();
  }

  public Vector getMapArray() {
    return vecMapArray;
  }

  public void buildMapArray() {
//    vecAvailableWorkersJobsCopyJobs.removeAllElements();
//    for(int i=0;i<vecJobCollection.size();i++) {
//      vecAvailableWorkersJobsCopyJobs.addElement(((SpecificJob)vecJobCollection.elementAt(i)).clone());
//    }

/*
    int intLargestDimension=vecAvailableWorkers.size();
    int intLargestDimension2=0;
    for(int i=0;i<vecAvailableWorkersJobs.size();i++) {
      Vector vecElements=(Vector)vecAvailableWorkersJobs.elementAt(i);

      if(vecElements.size()>intLargestDimension2)
        intLargestDimension2=vecElements.size();
    }
*/

    vecMapArray.removeAllElements();

/*
    Vector vecLastPosition=new Vector();
    for(int i=0;i<vecAvailableWorkersJobs.size();i++)
      vecLastPosition.addElement(new MatrixMapNode(MatrixMapNode.DO_INCLUSION, MatrixMapNode.DONT_IGNORE, i, 0));
*/

//    vecMapArray.addElement(cloneLastPosition(vecLastPosition));

//    buildMapArray(0, intLargestDimension, 0, 0, intLargestDimension2, 0);

    boolean blnNoJobs=true;

    int intIndex[]=new int[vecAvailableWorkersJobs.size()];
    for(int i=0;i<intIndex.length;i++)
      intIndex[i]=0;

    int intSizes[]=new int[intIndex.length];
    for(int i=0;i<intIndex.length;i++) {
      intSizes[i]=((Vector)vecAvailableWorkersJobs.elementAt(i)).size();
//System.out.println("size: "+i+" , "+intSizes[i]);

      if(intSizes[i]==0) {
        intIndex[i]=-1;
        intSizes[i]=-1;
      }
      else {
        blnNoJobs=false;
      }
    }

    if(blnNoJobs) {
      return;
    }

    int intIndexCopy[]=new int[intIndex.length];
    System.arraycopy(intIndex, 0, intIndexCopy, 0, intIndex.length);

    vecMapArray.addElement(intIndexCopy);

//System.out.println("before build map array: "+vecAvailableWorkersJobs.size());
    buildMapArray(intIndex, intSizes);
//System.out.println("after build map array: "+vecMapArray.size());

    Vector vecTree=new Vector();

    for(int i=0;i<vecMapArray.size();i++) {
      int intIndexNext[]=(int[])vecMapArray.elementAt(i);

      for(int ia=0;ia<intIndexNext.length;ia++) {
        Vector vecIndex=new Vector();
        vecIndex.addElement(new Integer(ia));

//        if(intIndexNext[ia]==-1)
//          continue;

/*
        String strTree="";

        for(int iz=intIndexNext[ia];iz<intSizes[ia], iz++) {
          if(
        }
*/

        String strTree=String.valueOf(ia)+","+String.valueOf(intIndexNext[ia]);

        if(intIndexNext.length==1) {
          vecTree.addElement(strTree);
        }
        else {
//System.out.println("before build tree: "+ia);
          Vector vecTree2=buildTree(strTree, intIndexNext, vecIndex, intIndexNext.length);
//System.out.println("after build tree: "+ia);

          for(int iz=0;iz<vecTree2.size();iz++)
            vecTree.addElement(vecTree2.elementAt(iz));
        }
      }
    }

//int intIndexZ[]=(int[])vecMapArray.elementAt(0);
//System.out.println("vecMapArray: "+intIndexZ.length);
//System.out.println("vecMapArray0: "+vecMapArray.size());

    vecMapArray.removeAllElements();

    for(int i=0;i<vecTree.size();i++) {
      String strTreeNext=(String)vecTree.elementAt(i);

      vecMapArray.addElement(strTreeNext);
    }
//System.out.println("vecMapArray1: "+vecMapArray.size());
  }

  public Vector buildTree(String strTree, int intIndex[], Vector vecIndex, int intCountDown) {
    Vector vecReturn=new Vector();

    String strTree0=strTree.toString();

    for(int i=0;i<intIndex.length;i++) {
      boolean blnMustContinue=false;

      for(int ia=0;ia<vecIndex.size();ia++) {
        int intIndexNext=((Integer)vecIndex.elementAt(ia)).intValue();

        if(intIndexNext==i) {
          blnMustContinue=true;

          break;
        }
      }

      if(blnMustContinue)
        continue;

//      if(intIndex[i]==-1)
//        continue;

      String strTree1=strTree0+":"+String.valueOf(i)+","+String.valueOf(intIndex[i]);

//      vecReturn.addElement(strTree1);

      if((intCountDown-2)==0) {
        vecReturn.addElement(strTree1);

        continue;
      }

      vecIndex.addElement(new Integer(i));

      Vector vecTree2=buildTree(strTree1, intIndex, vecIndex, intCountDown-1);

      for(int ia=0;ia<vecTree2.size();ia++)
        vecReturn.addElement(vecTree2.elementAt(ia));

      vecIndex.removeElementAt(vecIndex.size()-1);
    }

    return vecReturn;
  }

//  public void buildMapArray(int intDimension1Start, int intDimension1End, int intDimension1Current, int intDimension2Start, int intDimension2End, int intDimension2Current, Vector vecLastPosition) {

  public void buildMapArray(int intIndex[], int intSizes[]) {
    int intLowestOrder=0;
    for(;intLowestOrder<intSizes.length;intLowestOrder++) {
      if(intSizes[intLowestOrder]!=-1)
        break;
    }

    int intHighestOrder=intSizes.length-1;
    for(;intHighestOrder>=intLowestOrder;intHighestOrder--) {
      if(intSizes[intHighestOrder]!=-1)
        break;
    }

    while(countDown(intIndex, intSizes, intLowestOrder, intHighestOrder)) {
      int intIndexCopy[]=new int[intIndex.length];

      System.arraycopy(intIndex, 0, intIndexCopy, 0, intIndex.length);

      vecMapArray.addElement(intIndexCopy);
    }
  }

  public boolean countDown(int intIndex[], int intSizes[], int intLowestOrder, int intHighestOrder) {
    ++intIndex[intLowestOrder];

    if(intIndex[intLowestOrder]==intSizes[intLowestOrder]) {
      intIndex[intLowestOrder]=0;

      int i=intLowestOrder+1;
      int intLength=intHighestOrder+1;
      for(;i<intLength;i++) {
        if(intIndex[i]==(intSizes[i]-1))
          continue;

        if(intSizes[i]==-1)
          continue;

        break;
      }

      if(i==intLength)
        return false;

      ++intIndex[i];

      for(int ia=intLowestOrder+1;ia<i;ia++) {
        if(intSizes[ia]==-1)
          continue;

        intIndex[ia]=0;
      }
    }

    return true;
  }

/*
  public boolean countDown(int intIndex[], int intSizes[]) {
    int intIndexIncrement=intIndex.length-1;

    int intHighestOrderIndex=0;
    for(;intHighestOrderIndex<intIndex.length;intHighestOrderIndex++) {
      if(intSizes[intHighestOrderIndex]!=0)
        break;
    }

    if(intHighestOrderIndex==intIndex.length)
      return false;

    int intLowestOrderIndex=intIndex.length-1;
    for(;intLowestOrderIndex>=0;intLowestOrderIndex--) {
      if(intSizes[intLowestOrderIndex]!=0)
        break;
    }

    boolean blnSet=false;

    while(true) {
      if(intSizes[intIndexIncrement]==0) {
        --intIndexIncrement;

        if(intIndexIncrement==-1)
          return false;

        continue;
      }

      ++intIndex[intIndexIncrement];

      if(intIndex[intIndexIncrement]==intSizes[intIndexIncrement]) {
        if(intIndexIncrement==intHighestOrderIndex)
          return false;

        blnSet=true;

        --intIndexIncrement;
      }
      else {
        if(blnSet) {
          for(int i=intIndexIncrement+1;i<intLowestOrderIndex;i++) {
            if(intSizes[i]!=0)
              intIndex[i]=intSizes[i]-1;
          }

          intIndex[intLowestOrderIndex]=0;
        }

        break;
      }
    }

    return true;
  }
*/

/*
  public boolean countDown(int intIndex[], int intSizes[], intIndexIncrement) {
    ++intIndex[intIndexIncrement];

if(intIndex[intIndexIncrement]>intSizes[intIndexIncrement])
System.out.println("index too high");

    if(intIndex[intIndexIncrement]==intSizes[intIndexIncrement]) {
      intIndex[intIndex.length-1]=0;

      for(int i=intIndex.length-2;i>=0;i--) {
        ++intIndex[i];

        if(intIndex[i]==intSizes[i]) {
          if(i==0) {
            return false;
          }

          intIndex[i]=0;

//          for(int ia=i;ia<intIndex.length;ia++) {
//            intIndex[ia]=0;
//          }

        }
        else {
          break;
        }
      }
    }

    return true;
  }
*/

/*
  public Object cloneLastPosition(Vector vecLastPosition) {
    Vector vecLastPositionClone=new Vector();

    for(int i=0;i<vecLastPosition.size();i++)
      vecLastPositionClone.addElement(((MatrixMapNode)vecLastPosition.elementAt(i)).clone());

    return vecLastPositionClone;
  }
*/
}