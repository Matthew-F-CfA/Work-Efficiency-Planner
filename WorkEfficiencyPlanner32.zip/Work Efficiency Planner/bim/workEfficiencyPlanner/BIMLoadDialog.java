package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

  class BIMLoadDialog extends Dialog
  implements ActionListener {
    volatile List lstLoadName=new List(5);

    volatile Button btnLoad=new Button("Load");
    volatile Button btnCancel=new Button("Cancel");

    volatile boolean cancelIt=false;

    volatile String strLoadName="";

    volatile String strExtension="";

    BIMLoadDialog(Frame parent, String strExtension) {
      super(parent, "Load Dialog", true);

      this.strExtension=strExtension;

      try {
        File fileDir=new File(System.getProperty("user.dir"));
        String strList[]=fileDir.list();
        for(int i=0;i<strList.length;i++) {
          if(strList[i].endsWith(strExtension)) {
            lstLoadName.add(strList[i].substring(0, strList[i].length()-strExtension.length()));
          }
        }
      }
      catch(Exception ex) {
      }

      setLayout(new BorderLayout());

      add("Center", lstLoadName);

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnLoad);
      btnLoad.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/3, dimScreen.height/3);
      setSize(dimScreen.width/3, dimScreen.height/3);
    }

    public String getLoadName() {
      return strLoadName;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnLoad) {
        int intSelectedIndex=lstLoadName.getSelectedIndex();

        if(intSelectedIndex==-1)
          return;

        strLoadName=lstLoadName.getItem(intSelectedIndex);

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }
  }
