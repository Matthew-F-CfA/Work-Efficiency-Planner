package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class MainFrameWorker extends Frame
implements ActionListener, ItemListener, TextListener {
  List lstWorkers=new List(5);
  Button btnRemoveWorker=new Button("Remove Worker");

  TextField txtWorkerName=new TextField();
  TextArea txtWorkerDescription=new TextArea(5, 100);
  List lstWorkerProficiencies=new List(3);
  Button btnRemoveProficiency=new Button("Remove Proficiency");
  Button btnAddProficiency=new Button("Add Proficiency");
  List lstWorkerRestrictedCoworkers=new List(3);
  Button btnRemoveRestrictedCoworker=new Button("Remove Restricted Coworker");
  Button btnAddRestrictedCoworker=new Button("Add Restricted Coworker");

  Button btnAddSetWorker=new Button("Add Worker / Set Description, Proficiencies");

  Vector vecJobs=new Vector();

  Vector vecWorkers=new Vector();

  String strWorkerName="";
  String strWorkerDescription="";
  Vector vecWorkerProficiency=new Vector();
//  Vector vecWorkerRestrictedCoworkers=new Vector();


  public static void main(String args[]) {
    MainFrameWorker mFrame=new MainFrameWorker();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    try {
      File fileJobs=new File("Jobs");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileJobs));
      mFrame.vecJobs=(Vector)ois.readObject();
      ois.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }

    try {
      File fileWorkers=new File("Workers");
      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileWorkers));
      mFrame.vecWorkers=(Vector)ois.readObject();
      ois.close();

      for(int i=0;i<mFrame.vecWorkers.size();i++) {
        Worker workerNext=(Worker)mFrame.vecWorkers.elementAt(i);

        mFrame.lstWorkers.add(workerNext.getName());
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  MainFrameWorker() {
    super("Workers");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("North", new Label("Workers"));

    Panel pnlTemp2=new Panel();
    pnlTemp2.setLayout(new BorderLayout());
    pnlTemp2.add("Center", lstWorkers);
    lstWorkers.addItemListener(this);
    Panel pnlTemp2A=new Panel();
    pnlTemp2A.add(btnRemoveWorker);
    btnRemoveWorker.addActionListener(this);
    pnlTemp2.add("South", pnlTemp2A);

    add("Center", pnlTemp2);

    Panel pnlTemp=new Panel();
    pnlTemp.setLayout(new BorderLayout());
    Panel pnlTempA=new Panel();
    pnlTempA.setLayout(new GridLayout(1, 2));
    pnlTempA.add(new Label("Worker Name:"));
    pnlTempA.add(txtWorkerName);
    txtWorkerName.addTextListener(this);
    pnlTemp.add("North", pnlTempA);
    Panel pnlTempB=new Panel();
    pnlTempB.setLayout(new GridLayout(3, 1));
    pnlTempB.add(txtWorkerDescription);

    Panel pnlTempB1=new Panel();
    pnlTempB1.setLayout(new BorderLayout());
    pnlTempB1.add("Center", lstWorkerProficiencies);
    Panel pnlTempB1A=new Panel();
    pnlTempB1A.setLayout(new GridLayout(2, 1));
    pnlTempB1A.add(btnRemoveProficiency);
    btnRemoveProficiency.addActionListener(this);
    pnlTempB1A.add(btnAddProficiency);
    btnAddProficiency.addActionListener(this);
    pnlTempB1.add("South", pnlTempB1A);
    pnlTempB.add(pnlTempB1);

    Panel pnlTempB2=new Panel();
    pnlTempB2.setLayout(new BorderLayout());
    pnlTempB2.add("Center", lstWorkerRestrictedCoworkers);
    Panel pnlTempB2A=new Panel();
    pnlTempB2A.setLayout(new GridLayout(3, 1));
    pnlTempB2A.add(btnRemoveRestrictedCoworker);
    btnRemoveRestrictedCoworker.addActionListener(this);
    pnlTempB2A.add(btnAddRestrictedCoworker);
    btnAddRestrictedCoworker.addActionListener(this);
    Panel pnlTempB2A1=new Panel();
    pnlTempB2A1.add(btnAddSetWorker);
    btnAddSetWorker.addActionListener(this);
    pnlTempB2A.add(pnlTempB2A1);
    pnlTempB2.add("South", pnlTempB2A);
    pnlTempB.add(pnlTempB2);

    pnlTemp.add("Center", pnlTempB);

    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnRemoveWorker) {
      int intSelectedIndex=lstWorkers.getSelectedIndex();

      if(intSelectedIndex==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Worker", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      Worker worker=(Worker)vecWorkers.elementAt(intSelectedIndex);

      File files[]=new File[0];

      File filesCopy[]=new File[0];

      try {
        File file=new File(System.getProperty("user.dir"));

//System.out.println("user.dir:"+file.getAbsolutePath());

        files=file.listFiles();

        files=BIMFileUtility.narrowFiles(files, ".batch");

        filesCopy=BIMFileUtility.copyFiles(files);

        for(int i=0;i<files.length;i++) {
          String strName=files[i].getName();

          if(strName.endsWith(".batch")) {
            File fileBatch=files[i];

            ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileBatch));
            Vector vecWorkerBatch=(Vector)ois.readObject();
            ois.close();

            for(int ia=0;ia<vecWorkerBatch.size();ia++) {
              Worker workerNext=(Worker)vecWorkerBatch.elementAt(ia);

              if(workerNext.getName().equals(worker.getName())) {
                vecWorkerBatch.removeElementAt(ia);

                --ia;
              }

              removeRestrictedCoworkers(workerNext, worker.getName());
            }

            ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileBatch));
            oos.writeObject(vecWorkerBatch);
            oos.close();
          }
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();

        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Worker", "Error. Unable to access worker batches.");
        bDialog.show();

        try {
          BIMFileUtility.restoreFiles(filesCopy, files);
        }
        catch(Exception ex2) {
          BIMMessageDialog bDialog2=new BIMMessageDialog(this, "Remove Worker", "Critical Error. Restore a backup.");
          bDialog2.show();
        }

        return;
      }


      vecWorkers.removeElementAt(intSelectedIndex);
      lstWorkers.remove(intSelectedIndex);
      lstWorkerProficiencies.removeAll();
      lstWorkerRestrictedCoworkers.removeAll();
      txtWorkerName.setText("");
      txtWorkerDescription.setText("");

      vecWorkerProficiency.removeAllElements();

      Vector vecRestricted=worker.getRestrictedCoworkers();
      for(int i=0;i<vecRestricted.size();i++) {
        Worker workerNext=(Worker)vecRestricted.elementAt(i);

        for(int ia=0;ia<vecWorkers.size();ia++) {
          Worker workerNext2=(Worker)vecWorkers.elementAt(ia);

          if(workerNext.getName().equals(workerNext2.getName())) {
            removeRestrictedCoworkers(workerNext2, worker.getName());

            break;
          }
        }
      }

      saveWorkers();
    }
    else if(evSource==btnRemoveProficiency) {
      int intSelectedIndex0=lstWorkers.getSelectedIndex();

      if(intSelectedIndex0==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Proficiency", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      int intSelectedIndex=lstWorkerProficiencies.getSelectedIndex();

      if(intSelectedIndex==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Proficiency", "Error. You must select a proficiency from the list.");
        bDialog.show();

        return;
      }

      lstWorkerProficiencies.remove(intSelectedIndex);

      vecWorkerProficiency.removeElementAt(intSelectedIndex);

//      saveWorkers();
    }
    else if(evSource==btnAddProficiency) {
      int intSelectedIndex0=lstWorkers.getSelectedIndex();

      if(intSelectedIndex0==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Add Proficiency", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      AddProficiencyDialog aDialog=new AddProficiencyDialog(this);
      aDialog.show();

      if(aDialog.cancelIt)
        return;

      double dblRate=aDialog.getRate();

      double dblPayRate=aDialog.getPayRate();

      boolean blnAlwaysUseWorkerPayRate=aDialog.alwaysUseWorkerPayRate();

      Job job=aDialog.getJob();

      String strStr=job.getName()+": "+String.valueOf(dblRate)+" , "+String.valueOf(dblPayRate);

      lstWorkerProficiencies.add(strStr);

//      double dblRate=Double.valueOf(strRateNumerator).doubleValue()/Double.valueOf(strRateDenominator).doubleValue();

      vecWorkerProficiency.addElement(new JobProficiency(dblRate, dblPayRate, blnAlwaysUseWorkerPayRate, job));

//      saveWorkers();
    }
    else if(evSource==btnRemoveRestrictedCoworker) {
      int intSelectedIndex0=lstWorkers.getSelectedIndex();

      if(intSelectedIndex0==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Restricted Coworker", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      int intSelectedIndex=lstWorkerRestrictedCoworkers.getSelectedIndex();

      if(intSelectedIndex==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Restricted Coworker", "Error. You must select a restricted worker from the list.");
        bDialog.show();

        return;
      }

      String strWorkerName=lstWorkers.getItem(intSelectedIndex0);

      File files[]=new File[0];

      File filesCopy[]=new File[0];

      try {
        File file=new File(System.getProperty("user.dir"));

//System.out.println("user.dir:"+file.getAbsolutePath());

        files=file.listFiles();

        files=BIMFileUtility.narrowFiles(files, ".batch");

        filesCopy=BIMFileUtility.copyFiles(files);

        for(int i=0;i<files.length;i++) {
          String strName=files[i].getName();

          if(strName.endsWith(".batch")) {
            File fileBatch=files[i];

            ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileBatch));
            Vector vecWorkerBatch=(Vector)ois.readObject();
            ois.close();

            for(int ia=0;ia<vecWorkerBatch.size();ia++) {
              Worker workerNext=(Worker)vecWorkerBatch.elementAt(ia);

              removeRestrictedCoworkers(workerNext, strWorkerName);
            }

            ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileBatch));
            oos.writeObject(vecWorkerBatch);
            oos.close();
          }
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();

        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Remove Worker", "Error. Unable to access worker batches.");
        bDialog.show();

        try {
          BIMFileUtility.restoreFiles(filesCopy, files);
        }
        catch(Exception ex2) {
          BIMMessageDialog bDialog2=new BIMMessageDialog(this, "Remove Worker", "Critical Error. Restore a backup.");
          bDialog2.show();
        }

        return;
      }


      lstWorkerRestrictedCoworkers.remove(intSelectedIndex);

//      vecWorkerRestrictedCoworkers.removeElementAt(intSelectedIndex);

      Worker worker0=(Worker)vecWorkers.elementAt(intSelectedIndex0);

      Vector vecWorkerRestrictedCoworkers0=worker0.getRestrictedCoworkers();

      Worker worker=(Worker)vecWorkerRestrictedCoworkers0.elementAt(intSelectedIndex);

      vecWorkerRestrictedCoworkers0.removeElementAt(intSelectedIndex);

      Vector vecWorkerRestrictedCoworkers=worker.getRestrictedCoworkers();

      for(int i=0;i<vecWorkerRestrictedCoworkers.size();i++) {
        Worker workerNext=(Worker)vecWorkerRestrictedCoworkers.elementAt(i);

        if(workerNext.getName().equals(strWorkerName)) {
          vecWorkerRestrictedCoworkers.removeElementAt(i);

          break;
        }
      }

      saveWorkers();
    }
    else if(evSource==btnAddRestrictedCoworker) {
      int intSelectedIndex0=lstWorkers.getSelectedIndex();

      if(intSelectedIndex0==-1) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Add Restricted Coworker", "Error. You must select a worker from the list.");
        bDialog.show();

        return;
      }

      AddRestrictedCoworkerDialog aDialog=new AddRestrictedCoworkerDialog(this);
      aDialog.show();

      if(aDialog.cancelIt)
        return;

      Worker worker=aDialog.getWorker();

      lstWorkerRestrictedCoworkers.add(worker.getName());

//      vecWorkerRestrictedCoworkers.addElement(worker);

      Worker worker0=(Worker)vecWorkers.elementAt(intSelectedIndex0);

      Vector vecWorkerRestrictedCoworkers0=worker0.getRestrictedCoworkers();

      for(int i=0;i<vecWorkerRestrictedCoworkers0.size();i++) {
        Worker workerNext=(Worker)vecWorkerRestrictedCoworkers0.elementAt(i);

        if(workerNext.getName().equals(worker.getName())) {
          return;
        }
      }

      vecWorkerRestrictedCoworkers0.addElement(worker);

      worker.getRestrictedCoworkers().addElement(worker0);

      saveWorkers();
    }
    else if(evSource==btnAddSetWorker) {
      String strWorkerName=txtWorkerName.getText();

      if(strWorkerName.length()==0) {
        BIMMessageDialog bDialog=new BIMMessageDialog(this, "Add/Set Worker", "Error. You must enter a worker's name.");
        bDialog.show();

        return;
      }

      for(int i=0;i<vecWorkers.size();i++) {
        Worker workerNext=(Worker)vecWorkers.elementAt(i);

        if(strWorkerName.equals(workerNext.getName())) {
          Vector vecJPClone=new Vector();
          for(int ia=0;ia<vecWorkerProficiency.size();ia++) {
            JobProficiency jpNext=(JobProficiency)vecWorkerProficiency.elementAt(ia);

            vecJPClone.addElement(jpNext.clone());
          }

          workerNext.setJobProficiencies(vecJPClone);


/*
          Vector vecRCClone=new Vector();
          for(int ia=0;ia<vecWorkerRestrictedCoworkers.size();ia++) {
            Worker wNext=(Worker)vecWorkerRestrictedCoworkers.elementAt(ia);

            vecRCClone.addElement(wNext.clone());
          }

          workerNext.setRestrictedCoworkers(vecRCClone);
*/

          saveWorkers();

          return;
        }
      }

      String strWorkerDescription=txtWorkerDescription.getText();

      Worker worker=new Worker(strWorkerName, strWorkerDescription);

//      lstWorkers.add(strWorkerName);

      vecWorkers.addElement(worker);

      vecWorkers=BIMSetSorter.sortVector(vecWorkers, "Worker");

      int intWorkerIndex=-1;

      lstWorkers.removeAll();
      for(int i=0;i<vecWorkers.size();i++) {
        Worker workerNext=(Worker)vecWorkers.elementAt(i);

        lstWorkers.add(workerNext.getName());

        if(workerNext.getName().equals(strWorkerName))
          intWorkerIndex=i;
      }      

      vecWorkerProficiency=worker.getJobProficiencies();
//      vecWorkerRestrictedCoworkers=worker.getRestrictedCoworkers();

      lstWorkers.select(intWorkerIndex);

      lstWorkerProficiencies.removeAll();
      lstWorkerRestrictedCoworkers.removeAll();

      saveWorkers();
    }
  }

  public void itemStateChanged(ItemEvent ie) {
    Object evSource=ie.getSource();

    if(evSource==lstWorkers) {
      int intSelectedIndex=lstWorkers.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      Worker worker=(Worker)vecWorkers.elementAt(intSelectedIndex);

      setWorkerInfo(worker);

/*
      lstWorkerRestrictedCoworkers.removeAll();
      for(int i=0;i<vecWorkerRestrictedCoworkers.size();i++) {
        Worker wNext=(Worker)vecWorkerRestrictedCoworkers.elementAt(i);

        lstWorkerRestrictedCoworkers.add(wNext.getName());
      }
*/
    }
  }

  public void textValueChanged(TextEvent te) {
    Object evSource=te.getSource();

    if(evSource==txtWorkerName) {
      String strWorkerName=txtWorkerName.getText();

      lstWorkerProficiencies.removeAll();
      lstWorkerRestrictedCoworkers.removeAll();      

      int i=0;
      for(;i<vecWorkers.size();i++) {
        Worker workerNext=(Worker)vecWorkers.elementAt(i);

        if(workerNext.getName().equals(strWorkerName)) {
          setWorkerInfo(workerNext);

          lstWorkers.select(i);

          return;
        }
      }

      if(i==vecWorkers.size()) {
        txtWorkerDescription.setText("");

        vecWorkerProficiency.removeAllElements();
        lstWorkerProficiencies.removeAll();

        lstWorkerRestrictedCoworkers.removeAll();

        int intWorkerIndex=lstWorkers.getSelectedIndex();

        if(intWorkerIndex==-1)
          return;

        lstWorkers.deselect(intWorkerIndex);
      }
    }
  }

  public void setWorkerInfo(Worker worker) {
    txtWorkerName.removeTextListener(this);
    txtWorkerName.setText(worker.getName());
    txtWorkerName.addTextListener(this);
    txtWorkerDescription.setText(worker.getDescription());

    Vector vecWorkerProficiency0=worker.getJobProficiencies();

    Vector vecJPClone=new Vector();
    for(int ia=0;ia<vecWorkerProficiency0.size();ia++) {
      JobProficiency jpNext=(JobProficiency)vecWorkerProficiency0.elementAt(ia);

      vecJPClone.addElement(jpNext.clone());
    }

    vecWorkerProficiency=vecJPClone;

    Vector vecWorkerRestrictedCoworkers0=worker.getRestrictedCoworkers();

//      Vector vecRCClone=new Vector();
    lstWorkerRestrictedCoworkers.removeAll();
    for(int ia=0;ia<vecWorkerRestrictedCoworkers0.size();ia++) {
      Worker wNext=(Worker)vecWorkerRestrictedCoworkers0.elementAt(ia);

//        vecRCClone.addElement(wNext.clone());
      lstWorkerRestrictedCoworkers.add(wNext.getName());
    }

//      vecWorkerRestrictedCoworkers=vecRCClone;


    lstWorkerProficiencies.removeAll();
    for(int i=0;i<vecWorkerProficiency.size();i++) {
      JobProficiency jpNext=(JobProficiency)vecWorkerProficiency.elementAt(i);

      String strStr=jpNext.getJob().getName()+": "+String.valueOf(jpNext.getRate())+" , "+String.valueOf(jpNext.getPayRate());

      lstWorkerProficiencies.add(strStr);
    }
  }

  public void removeRestrictedCoworkers(Worker workerNext2, String strWorkerToRemove) {
    Vector vecRestricted2=workerNext2.getRestrictedCoworkers();

    for(int iz=0;iz<vecRestricted2.size();iz++) {
      Worker workerNext3=(Worker)vecRestricted2.elementAt(iz);

      if(workerNext3.getName().equals(strWorkerToRemove)) {
        vecRestricted2.removeElementAt(iz);

        break;
      }
    }
  }

  public void saveWorkers() {
    try {
      File fileWorkers=new File("Workers");
      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(fileWorkers));
      oos.writeObject(vecWorkers);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  class AddProficiencyDialog extends Dialog
  implements ActionListener {
    TextField txtRate=new TextField();
    TextField txtPayRate=new TextField();
    Checkbox cbAlwaysUseWorkerPayRate=new Checkbox("Always use worker pay rate", true);
    List lstJob=new List(5);

    Button btnAddProficiency=new Button("Add Proficiency");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    double dblRate=0.0d;
    double dblPayRate=0.0d;
    boolean blnAlwaysUseWorkerPayRate=true;
    Job job=null;


    AddProficiencyDialog(Frame parent) {
      super(parent, "Add Proficiency", true);

      for(int i=0;i<vecJobs.size();i++) {
        Job jobNext=(Job)vecJobs.elementAt(i);

        lstJob.add(jobNext.getName());
      }

      setLayout(new BorderLayout());

      Panel pnlTemp=new Panel();
      pnlTemp.setLayout(new GridLayout(3, 2));
      pnlTemp.add(new Label("Work Rate:"));
      pnlTemp.add(txtRate);
      pnlTemp.add(new Label("Pay Rate:"));
      pnlTemp.add(txtPayRate);
      pnlTemp.add(cbAlwaysUseWorkerPayRate);
      pnlTemp.add(new Label(""));
      add("North", pnlTemp);

      add("Center", lstJob);

      Panel pnlTemp2=new Panel();
      pnlTemp2.add(btnAddProficiency);
      btnAddProficiency.addActionListener(this);
      pnlTemp2.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp2);

      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public double getRate() {
      return dblRate;
    }

    public double getPayRate() {
      return dblPayRate;
    }

    public boolean alwaysUseWorkerPayRate() { 
      return blnAlwaysUseWorkerPayRate;
    }

    public Job getJob() {
      return job;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddProficiency) {
        String strRate=txtRate.getText();
        dblRate=Double.valueOf(strRate).doubleValue();

        if(dblRate<=0.0d) {
          txtRate.setText("Error. Work rate must be higher than 0.0 .");
          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtRate.setText(strRate);

          return;
        }

        String strPayRate=txtPayRate.getText();
        dblPayRate=Double.valueOf(strPayRate).doubleValue();

        if(dblPayRate<0.0d) {
          txtPayRate.setText("Error. Pay rate must be 0.0 or higher.");
          try {
            Thread.sleep(3000l);
          }
          catch(Exception ex) {
          }

          txtPayRate.setText(strPayRate);

          return;
        }

        blnAlwaysUseWorkerPayRate=cbAlwaysUseWorkerPayRate.getState();

        int intSelectedIndex=lstJob.getSelectedIndex();

        if(intSelectedIndex==-1)
          return;

        job=(Job)vecJobs.elementAt(intSelectedIndex);

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }
  }

  class AddRestrictedCoworkerDialog extends Dialog
  implements ActionListener {
    List lstWorkers0=new List(5);

    Button btnAddRestricted=new Button("Add Restricted Coworker");
    Button btnCancel=new Button("Cancel");

    boolean cancelIt=false;

    Worker worker=null;


    AddRestrictedCoworkerDialog(Frame parent) {
      super(parent, "Add Restricted Coworker", true);

      for(int i=0;i<vecWorkers.size();i++) {
        Worker workerNext=(Worker)vecWorkers.elementAt(i);

        lstWorkers0.add(workerNext.getName());
      }

/*
      int intWorkerIndex=lstWorkers.getSelectedIndex();
      String strWorkerWorker=((Worker)vecWorkers.elementAt(intWorkerIndex)).getName();

      for(int i=0;i<vecWorkers.size();i++) {
        Worker workerNext=(Worker)vecWorkers.elementAt(i);

        if(!strWorkerWorker.equals(workerNext.getName()))        
          lstWorkers0.add(workerNext.getName());
      }
*/

      setLayout(new BorderLayout());

      add("Center", lstWorkers0);

      Panel pnlTemp=new Panel();
      pnlTemp.add(btnAddRestricted);
      btnAddRestricted.addActionListener(this);
      pnlTemp.add(btnCancel);
      btnCancel.addActionListener(this);
      add("South", pnlTemp);
      
      Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();
      setLocation(dimScreen.width/4, dimScreen.height/4);
      setSize(dimScreen.width/2, dimScreen.height/2);
    }

    public Worker getWorker() {
      return worker;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnAddRestricted) {
        int intWorkerIndex0=lstWorkers0.getSelectedIndex();

        if(intWorkerIndex0==-1)
          return;

        int intWorkerIndex=lstWorkers.getSelectedIndex();

        if(intWorkerIndex0==intWorkerIndex)
          return;

        worker=(Worker)vecWorkers.elementAt(intWorkerIndex0);

        cancelIt=false;

        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;

        dispose();
      }
    }
  }
}