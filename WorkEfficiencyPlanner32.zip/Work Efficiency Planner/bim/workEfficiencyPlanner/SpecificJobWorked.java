package bim.workEfficiencyPlanner;

class SpecificJobWorked
implements Cloneable {
  volatile String strWorkerName="";
  volatile Double dblWorkerRate=new Double(0.0d);
  volatile Double dblNumberOfHalfHourInWhenStarted=new Double(0);
  volatile Double dblNumberOfHalfHoursWorked=new Double(0);

  SpecificJobWorked(String strWorkerName, double dblWorkerRate0, double dblNumberOfHalfHourInWhenStarted0) {
    this.strWorkerName=strWorkerName;
    this.dblWorkerRate=new Double(dblWorkerRate0);
    this.dblNumberOfHalfHourInWhenStarted=new Double(dblNumberOfHalfHourInWhenStarted0);
  }

  SpecificJobWorked(String strWorkerName, double dblWorkerRate0, double dblNumberOfHalfHourInWhenStarted0, double dblNumberOfHalfHoursWorked0) {
    this.strWorkerName=strWorkerName;
    this.dblWorkerRate=new Double(dblWorkerRate0);
    this.dblNumberOfHalfHourInWhenStarted=new Double(dblNumberOfHalfHourInWhenStarted0);
    this.dblNumberOfHalfHoursWorked=new Double(dblNumberOfHalfHoursWorked0);
  }

  public String getName() {
    return strWorkerName;
  }

  public double getRate() {
    return dblWorkerRate.doubleValue();
  }

  public double getIn() {
    return dblNumberOfHalfHourInWhenStarted.doubleValue();
  }

  public double getWorked() {
    return dblNumberOfHalfHoursWorked.doubleValue();
  }

  public void setWorked(double dblNumberOfHalfHoursWorked0) {
    this.dblNumberOfHalfHoursWorked=new Double(dblNumberOfHalfHoursWorked0);
  }

  public Object clone() {
    SpecificJobWorked sjwClone=new SpecificJobWorked(getName().toString(), getRate(), getIn(), getWorked());

    return sjwClone;
  }
}