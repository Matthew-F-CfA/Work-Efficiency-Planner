package bim.workEfficiencyPlanner;

import java.awt.*;
import java.awt.event.*;

public class MainFrameSelector extends Frame
implements ActionListener {
  List lstSelector=new List(5);

  Button btnSelect=new Button("Select Frame");

  public static void main(String args[]) {
    MainFrameSelector mFrame=new MainFrameSelector();

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    mFrame.setLocation(dimScreen.width/4, dimScreen.height/4);
    mFrame.setSize(dimScreen.width/2, dimScreen.height/2);
    mFrame.setVisible(true);
  }

  MainFrameSelector() {
    super("Main Frame Selector");

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    lstSelector.add("Job");
    lstSelector.add("Worker");
    lstSelector.add("Worker Batch");
    lstSelector.add("Job Collection");
    lstSelector.add("Planner");

    add("North", new Label("Frames:"));

    add("Center", lstSelector);

    Panel pnlTemp=new Panel();
    pnlTemp.add(btnSelect);
    btnSelect.addActionListener(this);

    add("South", pnlTemp);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnSelect) {
      int intSelectedIndex=lstSelector.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      String strArgs[]=new String[0];

      if(intSelectedIndex==0) {
        MainFrameJob.main(strArgs);
      }
      else if(intSelectedIndex==1) {
        MainFrameWorker.main(strArgs);
      }
      else if(intSelectedIndex==2) {
        MainFrameWorkerBatch.main(strArgs);
      }
      else if(intSelectedIndex==3) {
        MainFrameJobCollection.main(strArgs);
      }
      else if(intSelectedIndex==4) {
        MainFramePlanner.main(strArgs);
      }

      setVisible(false);
    }
  }
}